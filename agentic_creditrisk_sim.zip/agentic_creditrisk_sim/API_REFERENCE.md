# AACP API Reference

Complete API documentation for the Agentic Audit Control Plane.

---

## Table of Contents

1. [Core Contracts](#1-core-contracts)
2. [Orchestrator Agent](#2-orchestrator-agent)
3. [Compliance Agent](#3-compliance-agent)
4. [Explainability Agent](#4-explainability-agent)
5. [Provenance Agent](#5-provenance-agent)
6. [FinOps Agent](#6-finops-agent)
7. [Model Components](#7-model-components)

---

## 1. Core Contracts

### 1.1 Decision Enum

```python
from enum import Enum

class Decision(Enum):
    ALLOW = "allow"
    ALLOW_WITH_OBLIGATIONS = "allow_with_obligations"
    HOLD = "hold"
    DENY = "deny"
```

**Description:** Four-level decision model for bounded autonomy.

**Usage:**
```python
from agentic_creditrisk_sim.agents.contracts import Decision

if artifact.outcome == Decision.HOLD:
    escalate_to_human(artifact)
```

---

### 1.2 PolicyProof

```python
@dataclass(frozen=True)
class PolicyProof:
    policy_id: str
    policy_version: str
    condition: str
    outcome: Decision
    triggered: bool
    evidence: Dict[str, Any]
    rationale: str
```

**Fields:**
- `policy_id`: Policy identifier (e.g., "P1_drift", "P2_bias")
- `policy_version`: Version string (e.g., "1.0")
- `condition`: Human-readable condition (e.g., "PSI > 0.2")
- `outcome`: Decision if policy triggers
- `triggered`: Boolean indicating if policy condition met
- `evidence`: Supporting data (PSI value, SHAP scores, etc.)
- `rationale`: Explanation of outcome

**Example:**
```python
proof = PolicyProof(
    policy_id="P1_drift",
    policy_version="1.0",
    condition="PSI > 0.2",
    outcome=Decision.HOLD,
    triggered=True,
    evidence={"psi": 0.25, "threshold": 0.2},
    rationale="Population shift detected in 'age' feature"
)
```

---

### 1.3 Obligation

```python
@dataclass(frozen=True)
class Obligation:
    obligation_id: str
    description: str
    due_by: Optional[str]
    owner: Optional[str]
    evidence_required: bool
```

**Fields:**
- `obligation_id`: Unique identifier
- `description`: Human-readable task
- `due_by`: Optional ISO 8601 deadline
- `owner`: Responsible party (human or agent)
- `evidence_required`: Whether proof of completion needed

**Example:**
```python
obligation = Obligation(
    obligation_id="obl_001",
    description="Notify risk officer of drift breach",
    due_by="2025-10-19T23:59:59Z",
    owner="risk_team@example.com",
    evidence_required=True
)
```

---

### 1.4 Explanation

```python
@dataclass(frozen=True)
class Explanation:
    explanation_id: str
    audience: str
    summary: str
    top_features: List[str]
    counterfactual: Optional[str]
    evidence_refs: List[str]
    confidence: float
```

**Fields:**
- `explanation_id`: Unique identifier
- `audience`: Target audience ("customer", "regulator", "auditor")
- `summary`: Plain-language explanation
- `top_features`: Most influential features
- `counterfactual`: Actionable alternative (if applicable)
- `evidence_refs`: References to SHAP/DiCE outputs
- `confidence`: Explanation reliability score

**Example:**
```python
explanation = Explanation(
    explanation_id="exp_001",
    audience="customer",
    summary="Declined due to high credit utilization",
    top_features=["credit_amount", "duration", "existing_credits"],
    counterfactual="Reducing loan duration to 18 months would likely result in approval",
    evidence_refs=["shap_001", "dice_001"],
    confidence=0.85
)
```

---

### 1.5 CostReport

```python
@dataclass(frozen=True)
class CostReport:
    base_inference_cost: float
    shap_cost: float
    dice_cost: float
    total_latency_ms: float
    carbon_g: float
    advisories: List[str]
```

**Fields:**
- `base_inference_cost`: Model inference cost (USD)
- `shap_cost`: SHAP computation cost (USD)
- `dice_cost`: DiCE counterfactual cost (USD)
- `total_latency_ms`: End-to-end latency (milliseconds)
- `carbon_g`: Estimated carbon footprint (grams CO2e)
- `advisories`: Warnings or recommendations

**Example:**
```python
cost_report = CostReport(
    base_inference_cost=0.001,
    shap_cost=0.002,
    dice_cost=0.005,
    total_latency_ms=125.5,
    carbon_g=0.02,
    advisories=["Budget at 90% - consider downshift"]
)

total_cost = (cost_report.base_inference_cost + 
              cost_report.shap_cost + 
              cost_report.dice_cost)
```

---

### 1.6 GovernanceArtifact

```python
@dataclass(frozen=True)
class GovernanceArtifact:
    episode_id: str
    timestamp: str
    inputs_ref: str
    model_version: str
    workflow: str
    signals: Dict[str, Any]
    policy_proofs: List[PolicyProof]
    explanation_ref: Optional[str]
    cost_report: CostReport
    outcome: Decision
    obligations: List[Obligation]
    seal: Dict[str, Any]
```

**Description:** Complete audit record for one decision episode.

**Methods:**
```python
def to_dict(self) -> dict:
    """Serialize artifact to JSON-compatible dictionary."""
```

**Example:**
```python
artifact = GovernanceArtifact(
    episode_id="ep_20251019_002736_0001",
    timestamp="2025-10-19T00:27:36Z",
    inputs_ref="inputs_abc123",
    model_version="v1.2.3",
    workflow="credit_risk",
    signals={"psi": 0.15, "shap_summary": {...}},
    policy_proofs=[...],
    explanation_ref="exp_001",
    cost_report=CostReport(...),
    outcome=Decision.ALLOW,
    obligations=[],
    seal={"hash": "0c5e23b8...", "sealed_at": "..."}
)

# Serialize
artifact_dict = artifact.to_dict()
```

---

## 2. Orchestrator Agent

### 2.1 Class: `OrchestratorAgent`

```python
from agentic_creditrisk_sim.agents.orchestrator import OrchestratorAgent

class OrchestratorAgent:
    def __init__(self):
        """Initialize orchestrator with all agent components."""
    
    def orchestrate(
        self,
        customer_data: Dict[str, Any],
        prediction: Dict[str, Any],
        model_version: str
    ) -> GovernanceArtifact:
        """
        Execute full AACP protocol for one episode.
        
        Args:
            customer_data: Feature dictionary
            prediction: Model output (decision, probability, score)
            model_version: Model identifier
            
        Returns:
            GovernanceArtifact: Sealed audit record
        """
    
    def get_governance_summary(self, artifact: GovernanceArtifact) -> str:
        """Generate human-readable governance summary."""
```

---

### 2.2 Method: `orchestrate()`

**Signature:**
```python
def orchestrate(
    customer_data: Dict[str, Any],
    prediction: Dict[str, Any],
    model_version: str
) -> GovernanceArtifact
```

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `customer_data` | `Dict[str, Any]` | Feature dictionary (age, duration, etc.) |
| `prediction` | `Dict[str, Any]` | Model output with keys: `decision`, `probability`, `score` |
| `model_version` | `str` | Model version identifier |

**Returns:** `GovernanceArtifact`

**Example:**
```python
orchestrator = OrchestratorAgent()

customer = {
    "age": 35,
    "job": "skilled",
    "duration": 24,
    "credit_amount": 5000
}

prediction = {
    "decision": "approve",
    "probability": 0.75,
    "score": 750
}

artifact = orchestrator.orchestrate(customer, prediction, "v1.2.3")

print(f"Outcome: {artifact.outcome.value}")
print(f"Cost: ${artifact.cost_report.base_inference_cost:.4f}")
```

---

### 2.3 Method: `get_governance_summary()`

**Signature:**
```python
def get_governance_summary(artifact: GovernanceArtifact) -> str
```

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `artifact` | `GovernanceArtifact` | Sealed governance artifact |

**Returns:** `str` (formatted summary)

**Example:**
```python
summary = orchestrator.get_governance_summary(artifact)
print(summary)

# Output:
# ─────────────────────────────────────
# GOVERNANCE SUMMARY
# ─────────────────────────────────────
# Episode: ep_20251019_002736_0001
# Outcome: allow
# Policies evaluated: 3
# Obligations: 0
# Cost: $0.0080
# Sealed: 2025-10-19T00:27:36+00:00
```

---

## 3. Compliance Agent

### 3.1 Class: `ComplianceAgent`

```python
from agentic_creditrisk_sim.agents.compliance import ComplianceAgent

class ComplianceAgent:
    def __init__(self, policy_path: str = "policies/policy_registry.yaml"):
        """Initialize with policy registry."""
    
    def check_p1_drift(self, psi_value: float) -> PolicyProof:
        """Check P1: Drift quarantine (PSI threshold)."""
    
    def check_p2_bias(self, shap_values: Dict[str, float]) -> PolicyProof:
        """Check P2: Bias proxy detection (protected features)."""
    
    def check_p3_explanation(
        self,
        decision: str,
        has_explanation: bool
    ) -> PolicyProof:
        """Check P3: Adverse action explanation requirement."""
    
    def evaluate_all(
        self,
        psi: float,
        shap_summary: Dict[str, float],
        decision: str,
        has_explanation: bool
    ) -> Tuple[List[PolicyProof], List[Obligation]]:
        """Evaluate all policies; return proofs and obligations."""
```

---

### 3.2 Method: `check_p1_drift()`

**Signature:**
```python
def check_p1_drift(psi_value: float) -> PolicyProof
```

**Policy:** P1 - Drift quarantine (PSI > 0.2 → HOLD)

**Example:**
```python
compliance = ComplianceAgent()

proof = compliance.check_p1_drift(psi_value=0.25)

if proof.triggered:
    print(f"Drift detected: {proof.rationale}")
    # Output: "Drift detected: Drift threshold breached (PSI=0.25)"
```

---

### 3.3 Method: `check_p2_bias()`

**Signature:**
```python
def check_p2_bias(shap_values: Dict[str, float]) -> PolicyProof
```

**Policy:** P2 - Bias proxy detection (|SHAP(protected)| > 0.05 → HOLD)

**Example:**
```python
shap_summary = {
    "age": 0.08,
    "job": 0.03,
    "duration": 0.25
}

proof = compliance.check_p2_bias(shap_summary)

if proof.triggered:
    print(f"Bias detected: {proof.evidence}")
    # Output: {'age': 0.08, 'job': 0.03, 'threshold': 0.05}
```

---

### 3.4 Method: `check_p3_explanation()`

**Signature:**
```python
def check_p3_explanation(decision: str, has_explanation: bool) -> PolicyProof
```

**Policy:** P3 - Adverse action explanation (reject → requires explanation)

**Example:**
```python
proof = compliance.check_p3_explanation(
    decision="reject",
    has_explanation=False
)

if proof.triggered:
    print(f"Explanation required: {proof.outcome.value}")
    # Output: "Explanation required: allow_with_obligations"
```

---

### 3.5 Method: `evaluate_all()`

**Signature:**
```python
def evaluate_all(
    psi: float,
    shap_summary: Dict[str, float],
    decision: str,
    has_explanation: bool
) -> Tuple[List[PolicyProof], List[Obligation]]
```

**Returns:** `(policy_proofs, obligations)`

**Example:**
```python
proofs, obligations = compliance.evaluate_all(
    psi=0.15,
    shap_summary={"age": 0.08, "duration": 0.25},
    decision="reject",
    has_explanation=True
)

print(f"Proofs: {len(proofs)}")
print(f"Triggered: {len([p for p in proofs if p.triggered])}")
print(f"Obligations: {len(obligations)}")
```

---

## 4. Explainability Agent

### 4.1 Class: `ExplainabilityAgent`

```python
from agentic_creditrisk_sim.agents.explainability import ExplainabilityAgent

class ExplainabilityAgent:
    def generate_explanation(
        self,
        customer_data: Dict[str, Any],
        prediction: Dict[str, Any],
        audience: str = "customer"
    ) -> Explanation:
        """
        Generate audience-conditioned explanation with counterfactuals.
        
        Args:
            customer_data: Feature dictionary
            prediction: Model output
            audience: Target audience ("customer", "regulator", "auditor")
            
        Returns:
            Explanation object
        """
```

**Example:**
```python
explainability = ExplainabilityAgent()

explanation = explainability.generate_explanation(
    customer_data={"age": 35, "duration": 24},
    prediction={"decision": "reject", "probability": 0.40},
    audience="customer"
)

print(explanation.summary)
print(explanation.counterfactual)
```

---

## 5. Provenance Agent

### 5.1 Class: `ProvenanceAgent`

```python
from agentic_creditrisk_sim.agents.provenance import ProvenanceAgent

class ProvenanceAgent:
    def __init__(self, db_path: str = "provenance.db"):
        """Initialize SQLite audit trail."""
    
    def log_decision(
        self,
        episode_id: str,
        decision: str,
        features: Dict[str, Any],
        policy_results: Dict[str, bool]
    ):
        """Log decision to audit trail."""
    
    def get_audit_trail(self, limit: int = 100) -> List[Dict]:
        """Retrieve recent audit entries."""
```

**Example:**
```python
provenance = ProvenanceAgent()

provenance.log_decision(
    episode_id="ep_001",
    decision="allow",
    features={"age": 35, "duration": 24},
    policy_results={"P1": False, "P2": False, "P3": False}
)

trail = provenance.get_audit_trail(limit=10)
```

---

## 6. FinOps Agent

### 6.1 Class: `FinOpsAgent`

```python
from agentic_creditrisk_sim.agents.finops import FinOpsAgent

class FinOpsAgent:
    def track_costs(
        self,
        has_shap: bool = False,
        has_dice: bool = False,
        latency_ms: float = 0.0
    ) -> CostReport:
        """
        Track costs for one episode.
        
        Args:
            has_shap: Whether SHAP was computed
            has_dice: Whether DiCE counterfactual was generated
            latency_ms: Total latency
            
        Returns:
            CostReport object
        """
    
    def get_cost_summary(self) -> Dict[str, Any]:
        """Get cumulative cost statistics."""
```

**Example:**
```python
finops = FinOpsAgent()

cost_report = finops.track_costs(
    has_shap=True,
    has_dice=True,
    latency_ms=125.5
)

print(f"Total cost: ${cost_report.base_inference_cost:.4f}")
print(f"Latency: {cost_report.total_latency_ms:.2f}ms")

summary = finops.get_cost_summary()
print(f"Total episodes: {summary['total_inferences']}")
print(f"Cumulative cost: ${summary['cumulative_cost']:.4f}")
```

---

## 7. Model Components

### 7.1 Function: `download_german_credit()`

```python
from agentic_creditrisk_sim.models.train_model import download_german_credit

def download_german_credit() -> pd.DataFrame:
    """
    Download German Credit Dataset from OpenML.
    
    Returns:
        DataFrame with 1000 samples, 21 columns (20 features + target)
    """
```

---

### 7.2 Function: `train_model()`

```python
from agentic_creditrisk_sim.models.train_model import train_model

def train_model(X_train, y_train):
    """
    Train GradientBoostingClassifier.
    
    Args:
        X_train: Training features
        y_train: Training labels
        
    Returns:
        Trained model
    """
```

---

### 7.3 Class: `CreditRiskPredictor`

```python
from agentic_creditrisk_sim.models.predict import CreditRiskPredictor

class CreditRiskPredictor:
    def __init__(
        self,
        model_path: str = "models/model.pkl",
        encoder_path: str = "models/encoder.pkl"
    ):
        """Load trained model and encoder."""
    
    def predict(self, features: pd.DataFrame) -> np.ndarray:
        """Predict class labels (0 or 1)."""
    
    def predict_proba(self, features: pd.DataFrame) -> np.ndarray:
        """Predict class probabilities."""
```

**Example:**
```python
predictor = CreditRiskPredictor()

features = pd.DataFrame([{
    "age": 35,
    "job": "skilled",
    "duration": 24,
    "credit_amount": 5000
}])

prediction = predictor.predict(features)[0]
probability = predictor.predict_proba(features)[0][1]

print(f"Prediction: {prediction}")
print(f"Probability: {probability:.4f}")
```

---

## 8. Constants

### 8.1 Cost Model (FinOps)

```python
BASE_COST = 0.001  # USD per inference
SHAP_COST = 0.002  # USD per SHAP computation
DICE_COST = 0.005  # USD per DiCE counterfactual
```

### 8.2 Policy Thresholds

```python
# P1: Drift
PSI_THRESHOLD = 0.2

# P2: Bias
SHAP_THRESHOLD = 0.05
PROTECTED_ATTRS = ["age", "job"]

# P3: Explanation
COUNTERFACTUAL_REQUIRED = True
MIN_FEATURES = 3
```

---

## 9. Error Handling

All agents raise standard Python exceptions:

```python
try:
    artifact = orchestrator.orchestrate(customer_data, prediction, "v1.2.3")
except FileNotFoundError:
    print("Model not trained. Run: make train")
except ValueError as e:
    print(f"Invalid input: {e}")
except Exception as e:
    print(f"Unexpected error: {e}")
```

---

## 10. Type Hints

All functions use Python type hints:

```python
from typing import Dict, Any, List, Optional, Tuple

def orchestrate(
    customer_data: Dict[str, Any],
    prediction: Dict[str, Any],
    model_version: str
) -> GovernanceArtifact:
    ...
```

---

**Generated:** October 18, 2025  
**Version:** 1.0.0  
**Status:** Complete
