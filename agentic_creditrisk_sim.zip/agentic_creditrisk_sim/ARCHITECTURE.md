# Agentic Audit Control Plane (AACP) - Architecture Documentation

## 1. Overview

The **Agentic Audit Control Plane (AACP)** is an agentic oversight layer that provides real-time governance for financial AI workflows. Instead of post-hoc dashboards, AACP introduces cooperating audit agents that reason about each model action as it happens, producing verifiable evidence and enforcing bounded autonomy.

**Key Principle:** Automate when safe, escalate when uncertain.

---

## 2. Scope & Assumptions

### Scope
- **Primary Domain:** Credit risk and treasury reconciliation
- **Extension:** Generalizable to similar BFSI workflows
- **Oversight Mode:** Real-time decision governance

### Design Principles
1. **Non-invasive:** Reads from model servers/workflows; writes governance artifacts; does not change model weights or core business logic
2. **Policy-based:** Policies reflect regulatory requirements (SR 11-7, EU AI Act) in machine-checkable form
3. **Privacy-preserving:** Only decision-relevant metadata stored; PII is tokenized/redacted
4. **Auditable:** Every decision produces a sealed, verifiable artifact

---

## 3. System Architecture

### 3.1 Agent Roles & Contracts

AACP is realized through **five specialized agents**:

| Agent | Responsibility | Output |
|-------|---------------|--------|
| **Orchestrator** | Episode coordination, consensus, sealing | GovernanceArtifact |
| **Compliance** | Policy evaluation (P1, P2, P3) | PolicyProof[], Obligation[] |
| **Provenance** | Tamper-evident audit trail | EvidenceRef[], Seal |
| **Explainability** | SHAP + counterfactuals | Explanation |
| **FinOps** | Cost/latency/carbon tracking | CostReport |

#### Contract Types

All agents use typed contracts for interoperability:

```python
@dataclass(frozen=True)
class PolicyProof:
    policy_id: str
    policy_version: str
    condition: str
    outcome: Decision
    triggered: bool
    evidence: Dict[str, Any]
    rationale: str

@dataclass(frozen=True)
class Obligation:
    obligation_id: str
    description: str
    due_by: Optional[str]
    owner: Optional[str]
    evidence_required: bool

@dataclass(frozen=True)
class Explanation:
    explanation_id: str
    audience: str
    summary: str
    top_features: List[str]
    counterfactual: Optional[str]
    evidence_refs: List[str]
    confidence: float

@dataclass(frozen=True)
class CostReport:
    base_inference_cost: float
    shap_cost: float
    dice_cost: float
    total_latency_ms: float
    carbon_g: float
    advisories: List[str]
```

---

### 3.2 Decision Model (Bounded Autonomy)

AACP uses a **four-level decision model**:

| Decision | Meaning | Action |
|----------|---------|--------|
| **ALLOW** | Safe to proceed | Automate |
| **ALLOW_WITH_OBLIGATIONS** | Proceed with conditions | Automate + Track |
| **HOLD** | Uncertain → Escalate | Human review |
| **DENY** | Block action | Prevent |

**Consensus Ordering:** Compliance > Safety > Cost > Latency

---

## 4. Interaction Protocol (One Episode)

Each decision goes through a standardized protocol:

```
┌─────────────────────────────────────────────────────────────┐
│ 1. INTENT                                                   │
│    Workflow proposes action (approve/decline)               │
│    → Orchestrator opens episode                             │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. SIGNALS                                                  │
│    Compute PSI (drift) and SHAP (feature importance)        │
│    → Attach as evidence nodes                               │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. COMPLIANCE                                               │
│    Evaluate P1 (drift), P2 (bias), P3 (explanation)         │
│    → Return PolicyProof[] + Obligation[]                    │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. EXPLAINABILITY (if required)                             │
│    Generate audience-conditioned explanation                │
│    → If adverse action: add counterfactual                  │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 5. FINOPS                                                   │
│    Track cost, latency, carbon                              │
│    → Issue advisories (e.g., "Budget at 90%")               │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ 6. CONSENSUS & SEAL                                         │
│    Apply ordering rule (Compliance > Safety > Cost)         │
│    → Commit or escalate                                     │
│    → Seal episode with cryptographic hash                   │
└─────────────────────────────────────────────────────────────┘
```

**Result:** Every episode yields a complete, verifiable audit bundle.

---

## 5. Policy Model

Policies are **declarative rules** referencing measurable signals:

```yaml
# Example: P1 - Drift Detection
P1:
  desc: "Drift quarantine"
  type: "psi_threshold"
  condition: "max(PSI) > 0.2"
  decision: "hold"
  obligations: ["notify_risk_officer"]
  effective_date: "2025-01-01"
  version: "1.0"
```

### Implemented Policies

| ID | Name | Condition | Action |
|----|------|-----------|--------|
| **P1** | Drift quarantine | PSI > 0.2 | HOLD + notify_risk_officer |
| **P2** | Bias proxy detection | \|SHAP(protected)\| > 0.05 | HOLD + human_review |
| **P3** | Adverse action explanation | Decision = reject | ALLOW_WITH_OBLIGATIONS(attach_explanation) |

**Auditability:** Every decision includes PolicyProof indicating which rule fired and supporting evidence.

---

## 6. Governance Artifact

Each episode produces a **portable, sealed artifact**:

```json
{
  "episode_id": "ep_20251018_143045_0001",
  "timestamp": "2025-10-18T14:30:45Z",
  "inputs_ref": "inputs_abc123",
  "model_version": "v1.2.3",
  "workflow": "credit_risk",
  
  "signals": {
    "psi_summary": 0.15,
    "shap_summary": {"age": 0.03, "duration": 0.25}
  },
  
  "policy_proofs": [
    {
      "policy_id": "P1_drift",
      "outcome": "allow",
      "triggered": false,
      "evidence": {"psi": 0.15, "threshold": 0.2}
    }
  ],
  
  "explanation_ref": "exp_...",
  "cost_report": {"total_cost": 0.008, "latency_ms": 125.5},
  "outcome": "allow",
  "obligations": [],
  
  "seal": {
    "hash": "0c5e23b83a8791f6...",
    "sealed_at": "2025-10-18T14:30:46Z",
    "sealed_by": "orchestrator_v1"
  }
}
```

**This artifact is the single source of truth for audits.**

---

## 7. Safety & Fallbacks

AACP enforces bounded autonomy through multiple interlocks:

| Condition | Action |
|-----------|--------|
| Uncertain explanations | HOLD + human review |
| Policy conflicts | Apply consensus ordering; log arbitration |
| Budget exceedance | FinOps advisory; downshift or require approval |
| Detected drift (PSI > 0.2) | Quarantine until validation |
| Missing evidence | Reject explanation; episode cannot be sealed |

**Result:** Compliance becomes a preventive control loop, not reactive.

---

## 8. Deployment Modes

AACP supports three integration modes:

### Mode 1: Observer
- **Action:** Monitor/log only
- **Use Case:** Quantify governance gaps without changing outcomes
- **Risk:** Low

### Mode 2: Advisory
- **Action:** Recommend outcomes; humans confirm
- **Use Case:** Pilot deployment, shadow mode
- **Risk:** Medium

### Mode 3: Autonomous
- **Action:** Enforce outcomes under thresholds; escalate exceptions
- **Use Case:** Production with defined SLOs
- **Risk:** High (but bounded by policies)

**Integration:** API-level (model servers, workflow engines, catalogs). No model retraining required.

---

## 9. Operational Metrics (SLOs)

| Metric | Target | Purpose |
|--------|--------|---------|
| **Governance completeness** | > 99% | % episodes with {policy_proof ∧ explanation_ref ∧ sealed} |
| **Audit latency (p95)** | < 150ms | Time from intent → sealed artifact |
| **Policy precision** | < 1% false holds | False positives on synthetic benchmarks |
| **Drift MTTR** | < 5min | Time from threshold breach → quarantine |
| **Cost per 1k decisions** | < $10 | With FinOps advisories enabled |

---

## 10. Code Structure

```
agentic_creditrisk_sim/
├── agents/
│   ├── contracts.py           # ✅ Typed contracts (Decision, PolicyProof, etc.)
│   ├── orchestrator.py        # ✅ AACP protocol implementation
│   ├── compliance.py          # ✅ P1, P2, P3 enforcement
│   ├── explainability.py      # SHAP + DiCE (extensible)
│   ├── provenance.py          # Audit trail tracking
│   └── finops.py              # ✅ Cost/latency tracking
│
├── policies/
│   └── policy_registry.yaml   # ✅ P1, P2, P3 definitions
│
└── models/
    ├── train_model.py         # ✅ GradientBoostingClassifier
    └── predict.py             # Inference pipeline
```

---

## 11. Example Usage

### Initialize Orchestrator

```python
from agentic_creditrisk_sim.agents.orchestrator import OrchestratorAgent

orchestrator = OrchestratorAgent()
```

### Run Episode

```python
# Customer data + model prediction
customer_data = {"age": 35, "duration": 24, "credit_amount": 5000}
prediction = {"decision": "approve", "probability": 0.75}

# Orchestrate AACP episode
artifact = orchestrator.orchestrate(
    customer_data=customer_data,
    prediction=prediction,
    model_version="v1.2.3"
)

# View governance summary
print(orchestrator.get_governance_summary(artifact))
```

### Output

```
Episode: ep_20251018_143045_0001
Outcome: allow
Policies evaluated: 3
Obligations: 0
Cost: $0.0080
Sealed: 2025-10-18T14:30:46+00:00
```

---

## 12. Regulatory Alignment

| Regulation | AACP Feature | Coverage |
|------------|--------------|----------|
| **SR 11-7** (Model Risk Management) | PolicyProof + Provenance | ✅ Comprehensive audit trail |
| **EU AI Act** (High-Risk Systems) | Explainability + Transparency | ✅ Counterfactuals + evidence |
| **FCRA** (Adverse Action Notices) | P3 + Obligation tracking | ✅ Explanation requirements |
| **ECOA** (Fair Lending) | P2 (Bias detection) | ✅ Protected attribute monitoring |

---

## 13. Next Steps

### Phase 1: Core Implementation (✅ Complete)
- [x] Agent contracts
- [x] Orchestrator protocol
- [x] Policy registry (P1, P2, P3)
- [x] Compliance agent

### Phase 2: Enhanced Explainability
- [ ] Real SHAP computation
- [ ] DiCE counterfactuals
- [ ] Audience-conditioned explanations

### Phase 3: Production Hardening
- [ ] Provenance database integration
- [ ] Distributed tracing
- [ ] SLO monitoring

### Phase 4: Extension
- [ ] Treasury reconciliation workflows
- [ ] Multi-model governance
- [ ] Federated AACP

---

## 14. References

- **SR 11-7:** Supervisory Guidance on Model Risk Management (Federal Reserve)
- **EU AI Act:** Regulation on Artificial Intelligence (European Commission)
- **FCRA:** Fair Credit Reporting Act
- **ECOA:** Equal Credit Opportunity Act

---

**Generated:** October 18, 2025  
**Version:** 1.0.0  
**Status:** ✅ Core Architecture Implemented
