# AACP Quick Command Reference

**Generated:** October 18, 2025

---

## ✅ Simulation Complete!

Results saved to: `results/simulation_results.csv`

**Metrics:**
- Total samples: 100
- Model accuracy: 92.00%
- Baseline latency: 2.50 ms (±0.40)
- AACP latency: 1.00 ms (±0.39)
- Total cost: $0.4150
- Policy triggers: P1=11, P2=0, P3=0

---

## 🚀 Next Steps

### 1. Launch Interactive Dashboard

```bash
# From the AgenticAIWorkspace directory:
streamlit run agentic_creditrisk_sim/ui/console.py
```

**Or use the shortcut:**
```bash
cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace
python3 -m streamlit run agentic_creditrisk_sim/ui/console.py
```

**Access:** Open browser at http://localhost:8501

**Dashboard Features:**
- 📊 KPI Cards: Total samples, accuracy, latency, policies passed, cost
- 📈 Latency Chart: Baseline vs AACP comparison
- 🔥 Policy Heatmap: P1/P2/P3 trigger frequencies
- 📋 Decision Breakdown: Pie charts, distributions, cost analysis
- 📜 Audit Trail: Filterable data table with CSV export

---

### 2. Run Ablation Study

```bash
# From the AgenticAIWorkspace directory:
python3 -m agentic_creditrisk_sim.ablation
```

**What it does:**
- Tests 4 configurations: Full AACP, No Provenance, No Compliance, No FinOps
- Runs with 5 random seeds: [42, 123, 456, 789, 1024]
- Measures impact of removing each agent
- Validates reproducibility (±0.1% tolerance)

**Expected Output:**
```
Ablation Impact:
  Provenance → -41% evidence coverage
  Compliance → +12 violations
  FinOps → +8% cost
```

**Output Files:**
- `results/ablation/ablation_summary.txt`
- `results/ablation/ablation_comparison.csv`
- Individual CSVs: `{config}_seed{N}.csv`

---

### 3. Re-run Simulation with Different Seeds

```bash
# Test reproducibility:
python3 -m agentic_creditrisk_sim.simulation.run_simulation --seed 123

# Without provenance:
python3 -m agentic_creditrisk_sim.simulation.run_simulation --no-provenance

# Without compliance:
python3 -m agentic_creditrisk_sim.simulation.run_simulation --no-compliance

# Without FinOps:
python3 -m agentic_creditrisk_sim.simulation.run_simulation --no-finops
```

---

## 📊 Dashboard Usage

Once the dashboard is running:

1. **Filter by Decision Type:**
   - Sidebar → "Decision Type" dropdown
   - Select: All / approve / reject

2. **Filter by Policy Triggers:**
   - Sidebar → "Policy Triggers" multi-select
   - Check: P1, P2, and/or P3

3. **Export Filtered Results:**
   - Go to "Audit Trail" tab
   - Click "📥 Download Filtered Results as CSV"

4. **View Latency Comparison:**
   - Go to "Latency Analysis" tab
   - See bar chart with error bars
   - Check overhead percentage

5. **Analyze Policy Triggers:**
   - Go to "Policy Heatmap" tab
   - See color-coded heatmap
   - View breakdown by decision type

---

## 🔍 Verify Dashboard is Working

**Expected KPI Card Values:**
- Total Samples: 100
- Model Accuracy: 92.0%
- Avg AACP Latency: ~1.0 ms
- Policies Passed: ~89.0%
- Total Cost: $0.415

**Expected Policy Triggers:**
- P1 (Drift): 11 triggers (11%)
- P2 (Bias): 0 triggers (0%)
- P3 (Explanation): 0 triggers (0%)

**Expected Decision Distribution:**
- Approve: ~77 (77%)
- Reject: ~23 (23%)

---

## 🛑 Stopping the Dashboard

Press `Ctrl+C` in the terminal running Streamlit.

---

## 📚 Documentation

- **Dashboard Guide:** `DASHBOARD_GUIDE.md`
- **Architecture:** `ARCHITECTURE.md`
- **API Reference:** `API_REFERENCE.md`
- **Quickstart:** `QUICKSTART.md`

---

## 🧪 Quick Validation

Run all validation tests:

```bash
cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace
python3 -m agentic_creditrisk_sim.validate
```

Expected output:
```
✅ Simulation test PASSED
✅ Reproducibility test PASSED
✅ Dashboard test PASSED
✅ ALL VALIDATION TESTS PASSED
```

---

## 🐛 Troubleshooting

### Dashboard won't load
**Problem:** "No simulation results found"
```bash
# Solution: Run simulation first
python3 -m agentic_creditrisk_sim.simulation.run_simulation
```

### Module not found error
**Problem:** `ModuleNotFoundError: No module named 'agentic_creditrisk_sim'`
```bash
# Solution: Run from correct directory
cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace
# Then run your command
```

### Streamlit not found
```bash
# Solution: Install streamlit
pip install streamlit plotly
```

---

## 📈 Paper-Ready Outputs

### Figures
1. **Latency Comparison:** Dashboard → Latency Analysis tab → Screenshot
2. **Policy Heatmap:** Dashboard → Policy Heatmap tab → Screenshot
3. **Decision Breakdown:** Dashboard → Decision Breakdown tab → Screenshot

### Tables
1. **AACP Performance:** Copy KPI card values
2. **Ablation Impact:** `results/ablation/ablation_summary.txt`
3. **Comparison Table:** `results/ablation/ablation_comparison.csv`

---

**Last Updated:** October 18, 2025  
**Status:** ✅ All systems operational
