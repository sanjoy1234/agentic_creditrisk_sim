# Governance & Provenance Quick Reference

## 🎯 What Was Built

### Core Modules
1. **agents/contracts.py** - Enhanced dataclasses (PolicyProof, Explanation, CostReport, Arbitration)
2. **provenance/store.py** - Evidence attachment & cryptographic sealing
3. **provenance/build_artifact.py** - Artifact builder with governance validation
4. **privacy/tokenize.py** - PII tokenization & regulator view
5. **tests/test_governance.py** - Comprehensive test suite (5/5 passing ✅)

---

## 🚀 Quick Start

### Run Tests
```bash
cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace
python3 -m agentic_creditrisk_sim.tests.test_governance
```

**Expected Output:**
```
✅ PASSED: Seal Order Invariance
✅ PASSED: Explanation Required
✅ PASSED: Policy Proof Structure
✅ PASSED: Arbitration on Conflict
✅ PASSED: PII Tokenization
✅ Passed: 5/5
```

---

## 📚 Key Functions

### Provenance Store
```python
from agentic_creditrisk_sim.provenance import store

# Attach evidence
node_id = store.attach_artifact(episode_id, "signal", {"psi": 0.15})

# Seal episode
seal_hash = store.seal_episode(episode_id)

# Verify seal
is_valid = store.verify_seal(episode_id, seal_hash)
```

### Artifact Builder
```python
from agentic_creditrisk_sim.provenance.build_artifact import (
    build_episode_artifact, persist_artifact, validate_artifact_completeness
)

# Build artifact
artifact = build_episode_artifact(
    episode_id=episode_id,
    inputs_ref="input_ref",
    model_version="v1.0",
    signals={"psi": 0.15},
    policy_proofs=[...],
    explanation_ref="exp_123",
    cost_report=cost_obj,
    outcome=Decision.ALLOW
)

# Validate
is_complete, issues = validate_artifact_completeness(artifact)

# Persist
file_path = persist_artifact(artifact, output_dir="runs/artifacts")
```

### PII Tokenization
```python
from agentic_creditrisk_sim.privacy import tokenize_record, scan_for_raw_pii

# Tokenize
tokenized = tokenize_record(raw_record)

# Verify no raw PII
violations = scan_for_raw_pii(tokenized)
assert len(violations) == 0
```

### Consensus & Arbitration
```python
from agentic_creditrisk_sim.agents.contracts import policy_weighted_consensus

# Resolve conflicts
final_decision, arbitration = policy_weighted_consensus(agent_decisions)

# Check arbitration
if arbitration:
    print(f"Winners: {arbitration.winners}")
    print(f"Losers: {arbitration.losers}")
    print(f"Reason: {arbitration.reason}")
```

---

## 🔍 Governance Rules

### P3 Gate (Explanation Required)
- **Rule:** All rejections (outcome=DENY) MUST have `explanation_ref`
- **Enforcement:** `validate_artifact_completeness()` checks this
- **Test:** `test_explanation_evidence_required` ✅

### Policy Proof Requirements
- **Rule:** All policy proofs MUST have:
  - `threshold` (float)
  - `observed_value` (float)
  - `evidence_node_ids` (list with ≥1 ID)
- **Test:** `test_policy_proof_has_threshold_and_observed` ✅

### Seal Order Invariance
- **Rule:** Seal hash must be identical regardless of node insertion order
- **Implementation:** Nodes sorted by evidence_id before hashing
- **Test:** `test_seal_order_invariant` ✅

### Consensus Priority
- **Rule:** Compliance > Safety > Cost > Latency
- **Implementation:** `AGENT_PRIORITY` dict + `policy_weighted_consensus()`
- **Test:** `test_arbitration_recorded_on_conflict` ✅

### PII Protection
- **Rule:** No raw PII in logs or artifacts
- **Implementation:** `tokenize_record()` with salted SHA256
- **Test:** `test_tokenization` ✅

---

## 📊 Governance Completeness KPI

**Formula:**
```python
governance_completeness = mean(
    has_policy_proof & 
    (has_explanation_if_reject | decision=="approve") & 
    is_sealed
)
```

**Target:** > 90%

**Validation:**
```python
is_complete, issues = validate_artifact_completeness(artifact)
```

---

## 🔐 Carbon Tracking

**CostReport Fields:**
- `cpu_seconds` (float) - CPU time consumed
- `gco2e` (float) - Grams CO2 equivalent = `cpu_seconds * DEVICE_FACTOR`
- `usd` (float) - Financial cost
- `total_cost_with_carbon` (property) - Combined metric

**Usage:**
```python
cost = CostReport(
    base_inference_cost=0.001,
    cpu_seconds=0.05,
    gco2e=0.025,  # or computed: cpu_seconds * 0.5
    total_latency_ms=125.0
)
```

---

## 📁 File Structure

```
agentic_creditrisk_sim/
├── agents/
│   └── contracts.py          ✅ Enhanced (400+ lines)
├── provenance/
│   ├── store.py             ✅ NEW (400 lines)
│   └── build_artifact.py    ✅ NEW (350 lines)
├── privacy/
│   ├── __init__.py          ✅ NEW (15 lines)
│   └── tokenize.py          ✅ NEW (350 lines)
├── tests/
│   └── test_governance.py   ✅ NEW (350 lines)
└── GOVERNANCE_IMPLEMENTATION.md ✅ NEW (documentation)
```

---

## ⏳ TODO: Integration Work

### 1. Update run_simulation.py
```python
from provenance import store
from privacy import tokenize_record

# For each sample:
episode_id = f"ep_{sample_id}"

# Attach evidence
store.attach_artifact(episode_id, "signal", {"psi": psi_score})
store.attach_artifact(episode_id, "policy_proof", {...})

# Tokenize inputs
tokenized_input = tokenize_record(raw_input)

# Seal episode
seal_hash = store.seal_episode(episode_id)

# Build artifact
artifact = build_episode_artifact(episode_id, ...)
persist_artifact(artifact)

# Track governance booleans
has_policy_proof = len(artifact["policy_proofs"]) > 0
has_explanation_if_reject = (outcome != "DENY") or (artifact["explanation_ref"] is not None)
is_sealed = artifact.get("seal", {}).get("hash") is not None
```

### 2. Update ui/console.py (Streamlit Dashboard)
```python
# Add KPI card
governance_completeness = df["governance_completeness"].mean()
st.metric("Governance Completeness", f"{governance_completeness:.1%}", delta="Target: 90%")

# Add columns to Audit Trail
df["seal_hash"] = df["seal_hash"].str[:16] + "..."
df["arbitration_count"] = df["arbitration"].notna().astype(int)

# Add Regulator View toggle
if st.sidebar.checkbox("Regulator View"):
    from privacy import apply_regulator_view
    df = apply_regulator_view(df)

# Add Carbon Trend chart
fig = px.line(df, x="sample_id", y="carbon_g", title="Carbon Emissions Trend")
st.plotly_chart(fig)
```

### 3. Update Orchestrator
```python
from agents.contracts import policy_weighted_consensus

# Collect agent decisions
agent_decisions = {
    "compliance": compliance_agent.evaluate(...),
    "finops": finops_agent.evaluate(...)
}

# Run consensus
final_decision, arbitration = policy_weighted_consensus(agent_decisions)

# Attach arbitration if conflicts occurred
if arbitration:
    store.attach_artifact(episode_id, "arbitration", {
        "rule": arbitration.rule,
        "winners": arbitration.winners,
        "losers": arbitration.losers
    })
```

---

## ✅ Verification Checklist

- [x] All 5 tests passing
- [x] Seal order invariance verified
- [x] P3 gate enforces explanation for rejections
- [x] Policy proofs have threshold, observed_value, evidence_node_ids
- [x] Arbitration records conflicts with winners/losers
- [x] PII tokenization with 0 raw PII violations
- [x] Carbon tracking in CostReport
- [ ] Integration with run_simulation.py
- [ ] Governance completeness KPI in dashboard
- [ ] Regulator view toggle in UI
- [ ] End-to-end artifact generation

---

## 📞 Support

**Documentation:**
- `GOVERNANCE_IMPLEMENTATION.md` - Full implementation details
- `ARCHITECTURE.md` - System architecture
- `DASHBOARD_GUIDE.md` - Dashboard usage

**Test Files:**
- `tests/test_governance.py` - Run all governance tests

**Key Modules:**
- `agents/contracts.py` - Data contracts
- `provenance/store.py` - Provenance management
- `privacy/tokenize.py` - PII protection
