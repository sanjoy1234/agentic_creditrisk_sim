# AACP Quickstart Guide

Get started with the Agentic Audit Control Plane in 5 minutes.

---

## Prerequisites

- **Python:** 3.10+
- **OS:** macOS, Linux, Windows (WSL)
- **Tools:** pip, virtualenv (optional)

---

## Installation

### 1. Clone/Navigate to Project

```bash
cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace/agentic_creditrisk_sim
```

### 2. Create Virtual Environment (Optional)

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies

```bash
make setup
```

**Manual Installation:**
```bash
pip install -r requirements.txt
```

### 4. Verify Environment

```bash
python3 verify_environment.py
```

**Expected Output:**
```
✅ All library imports successful
✅ Project structure validated
✅ Policy registry validated
✅ Model artifacts found
```

---

## Training the Model

### Option 1: Using Makefile

```bash
make train
```

### Option 2: Direct Command

```bash
cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace
python3 -m agentic_creditrisk_sim.models.train_model
```

**Expected Output:**
```
Downloading German Credit Dataset from OpenML...
Dataset shape: (1000, 21)
Training model...
Evaluating model...

Classification Report:
              precision    recall  f1-score   support

         0.0       0.53      0.70      0.60        90
         1.0       0.85      0.73      0.78       210

    accuracy                           0.73       300
   macro avg       0.69      0.71      0.69       300
weighted avg       0.75      0.73      0.73       300

ROC-AUC Score: 0.7782

Model saved: models/model.pkl
Encoder saved: models/encoder.pkl
```

---

## Running AACP Episodes

### Test Orchestrator

```bash
cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace
python3 -m agentic_creditrisk_sim.agents.orchestrator
```

**Sample Output:**
```
🔍 AACP EPISODE: ep_20251019_002736_0001

📊 Signals computed:
   PSI: 0.150
   Top SHAP features: ['age', 'duration', 'credit_amount']

⚖️ Compliance evaluated:
   P1: 🟢 passed
   P2: 🔴 TRIGGERED (bias proxy detected)
   P3: 🟢 passed

🎯 Consensus: hold

💡 Explanation generated: exp_ep_20251019_002736_0001

💰 Cost: $0.008000

🔒 Episode sealed: 0c5e23b83a8791f6...

─────────────────────────────────────
GOVERNANCE SUMMARY
─────────────────────────────────────
Episode: ep_20251019_002736_0001
Outcome: hold
Policies evaluated: 3
Obligations: 1
Cost: $0.0080
Sealed: 2025-10-19T00:27:36.999378+00:00
─────────────────────────────────────
```

---

## Programmatic Usage

### Example 1: Single Prediction with AACP

```python
from agentic_creditrisk_sim.agents.orchestrator import OrchestratorAgent

# Initialize
orchestrator = OrchestratorAgent()

# Customer data
customer = {
    "age": 35,
    "job": "skilled",
    "duration": 24,
    "credit_amount": 5000,
    "housing": "own"
}

# Model prediction (simulate)
prediction = {
    "decision": "approve",
    "probability": 0.75,
    "score": 750
}

# Run AACP episode
artifact = orchestrator.orchestrate(
    customer_data=customer,
    prediction=prediction,
    model_version="v1.2.3"
)

# Access results
print(f"Decision: {artifact.outcome.value}")
print(f"Sealed: {artifact.seal['sealed_at']}")
print(f"Policy Triggers: {len([p for p in artifact.policy_proofs if p.triggered])}")

# Get human-readable summary
print(orchestrator.get_governance_summary(artifact))
```

---

### Example 2: Batch Processing

```python
from agentic_creditrisk_sim.agents.orchestrator import OrchestratorAgent
import pandas as pd

orchestrator = OrchestratorAgent()

# Load test data
test_data = pd.read_csv("data/german_credit.csv").head(10)

# Process batch
artifacts = []
for idx, row in test_data.iterrows():
    customer_data = row.to_dict()
    
    # Simulate prediction
    prediction = {
        "decision": "approve" if row['target'] == 1 else "reject",
        "probability": 0.80
    }
    
    artifact = orchestrator.orchestrate(customer_data, prediction, "v1.2.3")
    artifacts.append(artifact)

# Analytics
holds = len([a for a in artifacts if a.outcome.value == "hold"])
print(f"Total episodes: {len(artifacts)}")
print(f"Holds (escalations): {holds}")
print(f"Total cost: ${sum(a.cost_report.base_inference_cost for a in artifacts):.4f}")
```

---

### Example 3: Accessing Policy Proofs

```python
artifact = orchestrator.orchestrate(customer_data, prediction, "v1.2.3")

# Check which policies were triggered
for proof in artifact.policy_proofs:
    if proof.triggered:
        print(f"⚠️ Policy {proof.policy_id} triggered:")
        print(f"   Condition: {proof.condition}")
        print(f"   Rationale: {proof.rationale}")
        print(f"   Evidence: {proof.evidence}")
```

---

## Running Simulation

```bash
make simulate
```

**Manual Command:**
```bash
cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace
python3 -m agentic_creditrisk_sim.simulation.run_simulation
```

---

## Launching UI Dashboard

```bash
make ui
```

**Manual Command:**
```bash
streamlit run ui/console.py
```

**Access:** Open browser at http://localhost:8501

---

## Understanding Decisions

AACP uses a **four-level decision model**:

| Decision | Symbol | Meaning | Action |
|----------|--------|---------|--------|
| **ALLOW** | 🟢 | Safe to automate | Proceed |
| **ALLOW_WITH_OBLIGATIONS** | 🟡 | Proceed with conditions | Track obligations |
| **HOLD** | 🟠 | Uncertain → Escalate | Human review required |
| **DENY** | 🔴 | Block action | Reject |

### Consensus Ordering

When policies conflict, AACP uses this priority:

```
Compliance > Safety > Cost > Latency
```

**Example:** If P1 (drift) says ALLOW but P2 (bias) says HOLD → Result is HOLD.

---

## Policy Registry

Policies are defined in `policies/policy_registry.yaml`:

### P1: Drift Detection
```yaml
P1:
  name: "Drift quarantine"
  metric: "psi_threshold"
  threshold: 0.2
  action: "quarantine"
  obligations: ["notify_risk_officer"]
```

**Meaning:** If Population Stability Index > 0.2, quarantine the decision.

### P2: Bias Proxy Detection
```yaml
P2:
  name: "Bias proxy detection"
  metric: "shap_threshold"
  threshold: 0.05
  protected_attrs: ["age", "job"]
  action: "flag_for_review"
```

**Meaning:** If SHAP values for protected features > 5%, flag for human review.

### P3: Adverse Action Explanation
```yaml
P3:
  name: "Adverse action explanation"
  applies_to: "reject"
  counterfactual_required: true
  min_features: 3
```

**Meaning:** Rejections require explanations with counterfactuals.

---

## Governance Artifact Fields

Every episode produces a `GovernanceArtifact`:

```python
@dataclass
class GovernanceArtifact:
    episode_id: str              # Unique episode ID
    timestamp: str               # ISO 8601 timestamp
    inputs_ref: str              # Reference to input data
    model_version: str           # Model version
    workflow: str                # Workflow name
    signals: Dict[str, Any]      # PSI, SHAP summaries
    policy_proofs: List[PolicyProof]  # Policy evaluations
    explanation_ref: Optional[str]     # Explanation ID
    cost_report: CostReport      # Cost/latency tracking
    outcome: Decision            # Final decision
    obligations: List[Obligation] # Required actions
    seal: Dict[str, Any]         # Cryptographic seal
```

### Accessing Fields

```python
print(f"Episode ID: {artifact.episode_id}")
print(f"Outcome: {artifact.outcome.value}")
print(f"Sealed at: {artifact.seal['sealed_at']}")

# Check obligations
if artifact.obligations:
    print("Obligations:")
    for obl in artifact.obligations:
        print(f"  - {obl.description}")
```

---

## Cost Tracking

FinOps agent tracks per-episode costs:

| Component | Cost |
|-----------|------|
| Base inference | $0.001 |
| SHAP computation | $0.002 |
| DiCE counterfactual | $0.005 |

**Example:** ALLOW decision with explanation = $0.001 + $0.002 + $0.005 = $0.008

Access via:
```python
print(f"Total cost: ${artifact.cost_report.base_inference_cost:.4f}")
print(f"Latency: {artifact.cost_report.total_latency_ms:.2f}ms")
```

---

## Troubleshooting

### Issue: Module not found

**Error:**
```
ModuleNotFoundError: No module named 'agentic_creditrisk_sim'
```

**Solution:**
Run from parent directory:
```bash
cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace
python3 -m agentic_creditrisk_sim.agents.orchestrator
```

---

### Issue: Model not found

**Error:**
```
FileNotFoundError: [Errno 2] No such file or directory: 'models/model.pkl'
```

**Solution:**
Train the model first:
```bash
make train
```

---

### Issue: YAML parsing error

**Error:**
```
yaml.scanner.ScannerError: mapping values are not allowed here
```

**Solution:**
Check `policies/policy_registry.yaml` for correct YAML indentation.

---

## Next Steps

1. **Read Architecture:** [ARCHITECTURE.md](ARCHITECTURE.md)
2. **Explore API:** [API_REFERENCE.md](API_REFERENCE.md)
3. **Customize Policies:** Edit `policies/policy_registry.yaml`
4. **Integrate with Production:** See deployment modes in ARCHITECTURE.md

---

## Support

- **Issues:** https://github.com/your-org/agentic_creditrisk_sim/issues
- **Docs:** [Full Documentation](README.md)
- **Examples:** `simulation/run_simulation.py`

---

**Generated:** October 18, 2025  
**Version:** 1.0.0
