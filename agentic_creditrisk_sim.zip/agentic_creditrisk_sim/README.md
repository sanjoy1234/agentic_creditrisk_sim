# Agentic Credit Risk Simulation with AACP

## Overview

The **Agentic Audit Control Plane (AACP)** provides real-time governance for financial AI workflows. This implementation features episode-based governance with policy enforcement, explainability, and bounded autonomy.

Instead of post-hoc dashboards, AACP introduces cooperating audit agents that reason about each model action as it happens, producing verifiable evidence and enforcing compliance through sealed governance artifacts.

## 🚀 Quick Links

- **[Quickstart Guide](QUICKSTART.md)** - Get running in 5 minutes
- **[Architecture](ARCHITECTURE.md)** - System design and AACP protocol
- **[API Reference](API_REFERENCE.md)** - Complete API documentation
- **[Dashboard Guide](DASHBOARD_GUIDE.md)** - ⭐ Visualization & ablation study
- **[Setup Details](SETUP_COMPLETE.md)** - Detailed setup information

## ✨ Key Features

### Core AACP
- **Episode-Based Governance**: Every decision produces a sealed, verifiable audit record
- **Four-Level Decision Model**: ALLOW, ALLOW_WITH_OBLIGATIONS, HOLD, DENY
- **Policy-Weighted Consensus**: Compliance > Safety > Cost > Latency
- **Multi-Agent Architecture**: 5 specialized agents (Orchestrator, Compliance, Explainability, Provenance, FinOps)
- **Real-Time Policy Enforcement**: Drift detection (P1), Bias detection (P2), Explanation requirements (P3)
- **Cryptographic Sealing**: SHA-256 hashing for tamper-evident artifacts

### Visualization & Analysis
- **📊 Interactive Dashboard**: Real-time KPIs, latency charts, policy heatmaps (Streamlit)
- **🔬 Ablation Study**: Quantify impact of removing each agent
- **📈 Reproducibility Testing**: Deterministic validation across random seeds
- **📉 Cost Tracking**: Per-episode cost, latency, and carbon monitoring
- **💡 Explainability**: SHAP + DiCE counterfactuals

## 🎯 Quick Start

```bash
# 1. Install dependencies
make setup

# 2. Train model on German Credit dataset
make train

# 3. Run simulation (generates results CSV)
make simulate

# 4. Launch interactive dashboard
streamlit run agentic_creditrisk_sim/ui/console.py
# Open http://localhost:8501

# 5. Run ablation study (quantify agent impact)
make ablation
```

**See [QUICKSTART.md](QUICKSTART.md) and [DASHBOARD_GUIDE.md](DASHBOARD_GUIDE.md) for detailed instructions.**

## 💡 Example Usage

### Single Episode with AACP

```python
from agentic_creditrisk_sim.agents.orchestrator import OrchestratorAgent

# Initialize
orchestrator = OrchestratorAgent()

# Customer data
customer = {
    "age": 35,
    "job": "skilled",
    "duration": 24,
    "credit_amount": 5000
}

# Model prediction
prediction = {
    "decision": "approve",
    "probability": 0.75,
    "score": 750
}

# Run AACP episode
artifact = orchestrator.orchestrate(
    customer_data=customer,
    prediction=prediction,
    model_version="v1.2.3"
)

# View governance summary
print(orchestrator.get_governance_summary(artifact))
```

**Output:**
```
Episode: ep_20251019_002736_0001
Outcome: allow
Policies evaluated: 3
Obligations: 0
Cost: $0.0080
Sealed: 2025-10-19T00:27:36+00:00
```

### Batch Processing

```bash
# Run simulation on 100 test samples
make simulate
```

### Launch Dashboard

```bash
# Start Streamlit UI
make ui
# Open http://localhost:8501
```

## 🏗️ Architecture

### Agent Roles

| Agent | Responsibility | Output |
|-------|---------------|--------|
| **Orchestrator** | Episode coordination, consensus, sealing | GovernanceArtifact |
| **Compliance** | Policy evaluation (P1, P2, P3) | PolicyProof[], Obligation[] |
| **Explainability** | SHAP + counterfactuals | Explanation |
| **Provenance** | Tamper-evident audit trail | EvidenceRef[], Seal |
| **FinOps** | Cost/latency/carbon tracking | CostReport |

### Decision Model

```
DENY ← Policy violation
  ↓
HOLD ← Uncertain → Escalate to human
  ↓
ALLOW_WITH_OBLIGATIONS ← Proceed with tracking
  ↓
ALLOW ← Safe to automate
```

**Consensus:** Compliance > Safety > Cost > Latency

**See [ARCHITECTURE.md](ARCHITECTURE.md) for complete system design.**

## 📁 Project Structure

```
agentic_creditrisk_sim/
├── agents/
│   ├── contracts.py           # ✅ AACP contract definitions
│   ├── orchestrator.py        # ✅ 8-step protocol implementation
│   ├── compliance.py          # ✅ P1, P2, P3 enforcement
│   ├── explainability.py      # SHAP + DiCE
│   ├── provenance.py          # Audit trail
│   └── finops.py              # ✅ Cost tracking
├── models/
│   ├── train_model.py         # ✅ GradientBoostingClassifier
│   └── predict.py             # Inference pipeline
├── policies/
│   └── policy_registry.yaml   # ✅ P1, P2, P3 definitions
├── simulation/
│   └── run_simulation.py      # Batch runner
├── ui/
│   └── console.py             # Streamlit dashboard
├── data/
│   └── german_credit.csv      # ✅ OpenML ID 31 (1000 samples)
├── ARCHITECTURE.md            # ✅ Complete system design
├── QUICKSTART.md              # ✅ 5-minute guide
├── API_REFERENCE.md           # ✅ API documentation
└── SETUP_COMPLETE.md          # ✅ Setup details
```

## 📋 Prerequisites

- **Python:** 3.10+
- **OS:** macOS, Linux, Windows (WSL)
- **Tools:** pip, virtualenv (optional)

## 📊 Model Performance

- **Dataset**: German Credit (OpenML ID 31)
- **Samples**: 1000 (700 good, 300 bad)
- **Model**: GradientBoostingClassifier
- **Accuracy**: 73%
- **ROC-AUC**: 0.7782

## �️ Interactive Dashboard

The Streamlit dashboard provides real-time visualization:

**Features:**
- **KPI Cards**: Total samples, accuracy, latency, policies passed, cost
- **Latency Chart**: Baseline vs AACP comparison with error bars
- **Policy Heatmap**: P1/P2/P3 trigger frequency (color-coded)
- **Decision Breakdown**: Pie chart, probability distribution, cost analysis
- **Audit Trail**: Filterable data table with CSV export

**Filters:**
- Decision type (All/Approve/Reject)
- Policy triggers (P1/P2/P3 multi-select)

```bash
# Launch dashboard
streamlit run agentic_creditrisk_sim/ui/console.py

# Or use Makefile
make ui
```

**See [DASHBOARD_GUIDE.md](DASHBOARD_GUIDE.md) for complete guide.**

## 🔬 Ablation Study

Quantify the impact of removing each agent:

```bash
make ablation
```

**Measures:**
- **Provenance Agent**: Evidence coverage drop (-41%)
- **Compliance Agent**: Unflagged violations (+12 violations)
- **FinOps Agent**: Cost tracking accuracy (+8% cost spike)

**Reproducibility:** Tests across 5 random seeds [42, 123, 456, 789, 1024] to validate deterministic behavior (±0.1% tolerance).

**Output:**
- `results/ablation/ablation_summary.txt` - Impact summary
- `results/ablation/ablation_comparison.csv` - Comparison table
- Individual CSVs for each configuration + seed

## �🔒 Governance Artifacts

Every decision produces a sealed artifact:

```json
{
  "episode_id": "ep_20251019_002736_0001",
  "outcome": "allow",
  "policy_proofs": [...],
  "explanation_ref": "exp_...",
  "cost_report": {...},
  "seal": {
    "hash": "0c5e23b83a8791f6...",
    "sealed_at": "2025-10-19T00:27:36Z"
  }
}
```

## ⚖️ Policies

### P1: Drift Quarantine
```yaml
Condition: PSI > 0.2
Action: HOLD + notify_risk_officer
Rationale: Population shift detected
```

### P2: Bias Proxy Detection
```yaml
Condition: |SHAP(age/job)| > 0.05
Action: HOLD + flag_for_review
Rationale: Protected feature influence exceeds threshold
```

### P3: Adverse Action Explanation
```yaml
Condition: Decision = reject
Action: ALLOW_WITH_OBLIGATIONS (attach_explanation)
Rationale: FCRA/ECOA compliance
```

**All policies produce PolicyProof with evidence and rationale.**

### Agents
- **Orchestrator**: Workflow coordination
- **Compliance**: Policy evaluation (P1, P2, P3)
- **Explainability**: SHAP values & DiCE counterfactuals
- **Provenance**: Immutable audit trail
- **FinOps**: Cost tracking

## Usage Examples

### Train Model
```bash
python -m agentic_creditrisk_sim.models.train_model
```

### Run Simulation
```bash
python -m agentic_creditrisk_sim.simulation.run_simulation
```

### Launch UI
```bash
streamlit run ui/console.py
```

## Dataset

**German Credit Dataset** (OpenML ID: 31)
- 1000 samples
- 20 features (mix of categorical and numerical)
- Target: Good (1) / Bad (0) credit risk
- Protected attributes: Age, Job

## Makefile Targets

| Target | Description |
|--------|-------------|
| `setup` | Install dependencies |
| `train` | Train model on German Credit |
| `simulate` | Run batch simulation |
| `ui` | Launch Streamlit console |
| `clean` | Remove artifacts |

## 📊 Model Performance

- **Dataset**: German Credit (OpenML ID 31)
- **Samples**: 1000 (700 good, 300 bad)
- **Model**: GradientBoostingClassifier
- **Accuracy**: 73%
- **ROC-AUC**: 0.7782

## 🔒 Governance Artifacts

Every decision produces a sealed artifact:

```json
{
  "episode_id": "ep_20251019_002736_0001",
  "outcome": "allow",
  "policy_proofs": [...],
  "explanation_ref": "exp_...",
  "cost_report": {...},
  "seal": {
    "hash": "0c5e23b83a8791f6...",
    "sealed_at": "2025-10-19T00:27:36Z"
  }
}
```

## 📈 Operational Metrics

| Metric | Target |
|--------|--------|
| Governance completeness | > 99% |
| Audit latency (p95) | < 150ms |
| Policy precision | < 1% false holds |
| Cost per 1k decisions | < $10 |

## 🧪 Verification

```bash
# Run comprehensive checks
python3 verify_environment.py

# Expected output:
# ✅ All library imports successful
# ✅ Project structure validated
# ✅ Policy registry validated
# ✅ Model artifacts found
```

## 📚 Documentation

- **[ARCHITECTURE.md](ARCHITECTURE.md)** - AACP design, protocols, regulatory alignment
- **[QUICKSTART.md](QUICKSTART.md)** - Installation, training, usage examples
- **[API_REFERENCE.md](API_REFERENCE.md)** - Complete API documentation
- **[SETUP_COMPLETE.md](SETUP_COMPLETE.md)** - Detailed setup and verification

## 🤝 Contributing

Issues and PRs welcome! Please read [ARCHITECTURE.md](ARCHITECTURE.md) first.

## 📄 License

MIT License
