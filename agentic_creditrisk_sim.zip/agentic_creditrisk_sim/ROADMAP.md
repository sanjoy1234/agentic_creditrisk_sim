# AACP Development Roadmap

This document outlines the planned enhancements and extensions for the Agentic Audit Control Plane.

---

## ✅ Phase 1: Core Implementation (COMPLETE)

**Status:** ✅ Complete  
**Completion Date:** October 18, 2025

### Deliverables
- [x] AACP contract definitions (Decision, PolicyProof, Obligation, Explanation, CostReport, GovernanceArtifact)
- [x] Orchestrator with 8-step protocol
- [x] Policy registry (P1 drift, P2 bias, P3 explanation)
- [x] Compliance agent with P1/P2/P3 enforcement
- [x] FinOps agent with cost tracking
- [x] Model training pipeline (GradientBoostingClassifier on German Credit)
- [x] Episode sealing with SHA-256 cryptographic hash
- [x] Comprehensive documentation (ARCHITECTURE, QUICKSTART, API_REFERENCE)

### Validated
- ✅ Model training: 73% accuracy, 0.7782 ROC-AUC
- ✅ Environment verification: 4/4 checks passing
- ✅ Orchestrator test: Episode created, policies evaluated, sealed
- ✅ All dependencies installed and working

---

## 🚧 Phase 2: Enhanced Explainability (IN PROGRESS)

**Status:** 🟡 Planned  
**Target:** Q4 2025

### Objectives
Upgrade explainability agent to provide production-grade explanations with real SHAP and DiCE computations.

### Tasks

#### 2.1 Real SHAP Integration
- [ ] Replace placeholder SHAP values with TreeExplainer
- [ ] Compute SHAP for GradientBoostingClassifier predictions
- [ ] Cache SHAP values for performance
- [ ] Add SHAP waterfall plots
- [ ] Implement force plots for single predictions

**Acceptance Criteria:**
- SHAP values computed in < 50ms (p95)
- Top 5 features identified correctly
- Evidence refs point to SHAP artifacts

#### 2.2 DiCE Counterfactuals
- [ ] Integrate DiCE for counterfactual generation
- [ ] Support multiple counterfactual scenarios (3-5 per rejection)
- [ ] Filter actionable counterfactuals (≥ 3 features changed)
- [ ] Validate counterfactuals against model
- [ ] Generate natural language descriptions

**Acceptance Criteria:**
- Counterfactuals generated in < 200ms
- ≥ 90% of rejections have valid counterfactuals
- Human evaluation: ≥ 80% rated "actionable"

#### 2.3 Audience-Conditioned Explanations
- [ ] Customer explanations: Plain language, actionable steps
- [ ] Regulator explanations: Technical detail, policy references
- [ ] Auditor explanations: Evidence chain, decision provenance

**Example:**
```python
# Customer
"Your application was declined primarily due to high credit utilization. 
Reducing your loan amount to $3,500 would likely result in approval."

# Regulator
"Decision: HOLD. Triggered policies: P2 (bias proxy detection). 
SHAP values for protected attribute 'age' exceeded threshold (0.08 > 0.05). 
Evidence: shap_001, dice_001. Sealed: 0c5e23b8..."
```

---

## 🔮 Phase 3: Production Hardening (PLANNED)

**Status:** 🟡 Planned  
**Target:** Q1 2026

### Objectives
Prepare AACP for production deployment with enterprise-grade reliability, observability, and security.

### Tasks

#### 3.1 Provenance Database Enhancement
- [ ] Replace SQLite with PostgreSQL/TimescaleDB
- [ ] Implement graph-based provenance (Neo4j integration)
- [ ] Store GovernanceArtifacts as immutable records
- [ ] Add evidence node linking (SHAP → DiCE → Explanation)
- [ ] Implement seal verification API
- [ ] Support tamper detection

**Schema:**
```sql
CREATE TABLE governance_artifacts (
    episode_id VARCHAR(50) PRIMARY KEY,
    timestamp TIMESTAMPTZ NOT NULL,
    outcome VARCHAR(30),
    seal_hash VARCHAR(64),
    artifact_json JSONB,
    sealed_at TIMESTAMPTZ
);

CREATE INDEX ON governance_artifacts (timestamp);
CREATE INDEX ON governance_artifacts USING GIN (artifact_json);
```

#### 3.2 Distributed Tracing
- [ ] Integrate OpenTelemetry
- [ ] Trace full episode lifecycle (intent → seal)
- [ ] Measure agent latencies (compliance, explainability, finops)
- [ ] Export to Jaeger/Zipkin
- [ ] Add correlation IDs

**Metrics:**
- Episode duration (p50, p95, p99)
- Agent-specific latencies
- Policy evaluation times
- SHAP/DiCE computation overhead

#### 3.3 SLO Monitoring
- [ ] Implement Prometheus metrics exporter
- [ ] Track governance completeness: `% episodes with {policy_proof ∧ explanation_ref ∧ sealed}`
- [ ] Track audit latency (p95): `intent → sealed < 150ms`
- [ ] Track policy precision: `false_holds / total_holds < 1%`
- [ ] Track cost per 1k decisions: `< $10`
- [ ] Alerting for SLO breaches

**Dashboards:**
- Grafana dashboard with SLO violations
- Real-time episode flow visualization
- Policy trigger frequency heatmap

#### 3.4 Security & Compliance
- [ ] Implement PII tokenization/redaction
- [ ] Add role-based access control (RBAC) for artifacts
- [ ] Encrypt sealed artifacts at rest
- [ ] Audit log integrity verification
- [ ] GDPR right-to-explanation compliance

---

## 🌟 Phase 4: Extensions & Integrations (FUTURE)

**Status:** 💡 Concept  
**Target:** Q2-Q3 2026

### 4.1 Multi-Model Governance
- [ ] Extend AACP to treasury reconciliation workflows
- [ ] Support ensemble models (boosting + neural nets)
- [ ] Implement model cascade governance (cheap model first, expensive if uncertain)
- [ ] Track model performance drift across ensemble

### 4.2 Federated AACP
- [ ] Distributed orchestration across data centers
- [ ] Consensus across federated agents
- [ ] Privacy-preserving governance (federated learning compliance)
- [ ] Cross-region policy enforcement

### 4.3 Advanced Explainability
- [ ] Contrastive explanations (why approve vs similar rejected case)
- [ ] Example-based explanations (k-nearest neighbors)
- [ ] Uncertainty quantification (conformal prediction intervals)
- [ ] Causal explanations (structural causal models)

### 4.4 Autonomous Remediation
- [ ] Auto-generated mitigation strategies for drift
- [ ] Dynamic threshold adjustment based on false hold rate
- [ ] Policy fine-tuning via reinforcement learning
- [ ] Self-healing governance (detect and fix policy conflicts)

### 4.5 Regulatory Alignment
- [ ] SR 11-7 compliance dashboard
- [ ] EU AI Act risk assessment automation
- [ ] FCRA adverse action notice generation
- [ ] ECOA fair lending analysis

### 4.6 UI/UX Enhancements
- [ ] Real-time episode monitoring (WebSocket updates)
- [ ] Interactive policy editor with validation
- [ ] Counterfactual simulator ("what if" tool)
- [ ] Explainability comparison view (customer vs regulator)
- [ ] Audit trail search and filtering

---

## 📊 Success Metrics

### Current Performance (Phase 1)

| Metric | Current | Target |
|--------|---------|--------|
| Model accuracy | 73% | ≥ 70% ✅ |
| ROC-AUC | 0.7782 | ≥ 0.75 ✅ |
| Environment checks | 4/4 passing | 4/4 ✅ |
| Orchestrator tests | Passing | Passing ✅ |

### Phase 2 Targets

| Metric | Current | Target |
|--------|---------|--------|
| SHAP latency (p95) | N/A (placeholder) | < 50ms |
| DiCE latency (p95) | N/A (placeholder) | < 200ms |
| Counterfactual success rate | N/A | ≥ 90% |
| Explanation quality (human eval) | N/A | ≥ 80% "actionable" |

### Phase 3 Targets (SLOs)

| Metric | Target |
|--------|--------|
| Governance completeness | > 99% |
| Audit latency (p95) | < 150ms |
| Policy precision | < 1% false holds |
| Drift MTTR | < 5min |
| Cost per 1k decisions | < $10 |

---

## 🛠️ Technical Debt

### Known Issues
1. **Explainability placeholders:** SHAP/DiCE use mock data (Phase 2 fix)
2. **SQLite limitations:** Not suitable for production scale (Phase 3 migration)
3. **No distributed tracing:** Cannot debug cross-agent latencies (Phase 3 OpenTelemetry)
4. **Manual testing:** Need automated integration tests (Phase 3)

### Refactoring Opportunities
- Extract consensus logic into pluggable strategy pattern
- Separate policy evaluation from compliance agent (policy engine abstraction)
- Add async/await for agent coordination (currently synchronous)
- Implement caching layer for SHAP values

---

## 🚀 Quick Wins

High-impact, low-effort improvements for next sprint:

1. **Add integration tests** (2 days)
   - Test full orchestration flow
   - Validate policy triggers
   - Check artifact serialization

2. **Real SHAP integration** (3 days)
   - Replace mock SHAP with TreeExplainer
   - Add caching for repeated queries
   - Benchmark performance

3. **Prometheus metrics** (2 days)
   - Export episode counts
   - Track policy trigger rates
   - Monitor cost/latency

4. **Docker containerization** (1 day)
   - Dockerfile for reproducibility
   - Docker Compose for full stack

5. **API endpoint** (2 days)
   - FastAPI endpoint for `/orchestrate`
   - JSON request/response
   - Swagger docs

---

## 🤝 Contributing

Want to contribute? Pick a task from Phase 2 or Phase 3!

### How to Contribute
1. Read [ARCHITECTURE.md](ARCHITECTURE.md) for system design
2. Check [API_REFERENCE.md](API_REFERENCE.md) for contracts
3. Open an issue describing your proposed change
4. Submit PR with tests and documentation

### High-Priority Areas
- Real SHAP/DiCE integration (Phase 2.1, 2.2)
- PostgreSQL migration (Phase 3.1)
- Integration tests (Technical Debt)

---

## 📅 Release Schedule

| Version | Phase | Target Date | Status |
|---------|-------|-------------|--------|
| v1.0.0 | Core AACP | Oct 2025 | ✅ Released |
| v1.1.0 | Real SHAP | Nov 2025 | 🟡 Planned |
| v1.2.0 | DiCE counterfactuals | Dec 2025 | 🟡 Planned |
| v2.0.0 | Production hardening | Q1 2026 | 💡 Concept |
| v3.0.0 | Extensions | Q2 2026 | 💡 Concept |

---

**Last Updated:** October 18, 2025  
**Maintainer:** AACP Core Team
