"""
Agentic Credit Risk Simulation
================================

A multi-agent system for credit risk assessment with compliance and explainability.
"""

__version__ = "1.0.0"
