"""
Compliance Agent - Policy enforcement.
"""

from typing import Dict, Any, List
import yaml
from pathlib import Path


class ComplianceAgent:
    """
    Enforces policies P1 (drift), P2 (bias), P3 (explanation).
    """
    
    def __init__(self, policy_path: str = None):
        """Load policy registry."""
        if policy_path is None:
            policy_path = Path(__file__).parent.parent / "policies" / "policy_registry.yaml"
        
        with open(policy_path) as f:
            registry = yaml.safe_load(f)
            self.policies = registry['policies']
    
    def check_p1_drift(self, psi_score: float) -> Dict[str, Any]:
        """Check P1: Drift quarantine."""
        p1 = self.policies['P1']
        threshold = p1['psi_threshold']
        
        if psi_score > threshold:
            return {
                "policy_id": "P1",
                "outcome": "fail",
                "reason": f"PSI {psi_score:.3f} > {threshold}",
                "action": p1['action']
            }
        return {"policy_id": "P1", "outcome": "pass"}
    
    def check_p2_bias(self, shap_values: Dict[str, float]) -> Dict[str, Any]:
        """Check P2: Bias flag."""
        p2 = self.policies['P2']
        threshold = p2['shap_threshold']
        protected = p2['protected']
        
        violations = []
        total_shap = sum(abs(v) for v in shap_values.values())
        
        for feature in protected:
            if feature in shap_values:
                contribution = abs(shap_values[feature]) / total_shap
                if contribution > threshold:
                    violations.append({
                        "feature": feature,
                        "contribution": contribution
                    })
        
        if violations:
            return {
                "policy_id": "P2",
                "outcome": "fail",
                "violations": violations,
                "action": p2['action']
            }
        return {"policy_id": "P2", "outcome": "pass"}
    
    def check_p3_explanation(self, decision: str, explanation: Dict[str, Any]) -> Dict[str, Any]:
        """Check P3: Explanation requirement."""
        p3 = self.policies['P3']
        
        if decision == "reject":
            if not explanation:
                return {
                    "policy_id": "P3",
                    "outcome": "fail",
                    "reason": "Missing explanation for rejection",
                    "action": p3['action']
                }
            
            if 'counterfactual' not in explanation:
                return {
                    "policy_id": "P3",
                    "outcome": "fail",
                    "reason": "Missing counterfactual",
                    "action": p3['action']
                }
            
            if len(explanation.get('top_features', [])) < p3['min_features']:
                return {
                    "policy_id": "P3",
                    "outcome": "fail",
                    "reason": f"Need at least {p3['min_features']} features in explanation",
                    "action": p3['action']
                }
        
        return {"policy_id": "P3", "outcome": "pass"}
    
    def evaluate_all(self, context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Evaluate all policies."""
        results = []
        
        # P1: Drift
        if 'psi_score' in context:
            results.append(self.check_p1_drift(context['psi_score']))
        
        # P2: Bias
        if 'shap_values' in context:
            results.append(self.check_p2_bias(context['shap_values']))
        
        # P3: Explanation
        if 'decision' in context and 'explanation' in context:
            results.append(self.check_p3_explanation(
                context['decision'],
                context['explanation']
            ))
        
        return results


if __name__ == "__main__":
    print("Compliance agent ready!")
