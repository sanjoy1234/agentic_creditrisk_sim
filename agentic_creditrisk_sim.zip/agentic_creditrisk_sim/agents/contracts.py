"""
Agentic Audit Control Plane (AACP) - Core Contracts
====================================================

Defines the contract types and protocols for AACP agent interactions.

Key Concepts:
- Episodes: Each decision gets a unique episode ID
- Contracts: Typed outputs (Decision, Obligation, PolicyProof, etc.)
- Protocol: Intent → Signals → Compliance → Explainability → FinOps → Consensus
- Governance: Every episode produces a sealed, verifiable artifact
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Any, Optional
from datetime import datetime


# ============================================================================
# Decision Types
# ============================================================================

class Decision(Enum):
    """
    Four-level decision model aligned with AACP bounded autonomy.
    """
    ALLOW = "allow"                                    # Safe to proceed
    ALLOW_WITH_OBLIGATIONS = "allow_with_obligations"  # Proceed with conditions
    HOLD = "hold"                                      # Escalate to human
    DENY = "deny"                                      # Block action


# ============================================================================
# Episode Context (Shared State)
# ============================================================================

@dataclass(frozen=True)
class EpisodeContext:
    """
    Shared context for one decision episode.
    
    Flow:
    1. Orchestrator creates context
    2. Each agent reads and appends outputs
    3. Orchestrator seals the episode
    """
    episode_id: str
    timestamp: str
    model_version: str
    workflow: str  # e.g., "credit_risk", "treasury_reconciliation"
    
    # Inputs (references, not raw data)
    inputs_ref: str  # Pointer to input data (tokenized)
    
    # Signals (computed before policy evaluation)
    signals: Dict[str, Any] = field(default_factory=dict)
    # Example: {"psi_summary": 0.15, "shap_summary": {...}}
    
    # Agent outputs (populated during episode)
    policy_proofs: List['PolicyProof'] = field(default_factory=list)
    obligations: List['Obligation'] = field(default_factory=list)
    explanation_ref: Optional[str] = None
    cost_report: Optional['CostReport'] = None
    
    # Final outcome
    outcome: Optional[Decision] = None
    
    # Seal (cryptographic summary)
    seal: Optional[Dict[str, Any]] = None


# ============================================================================
# Obligation (What Must Be Done)
# ============================================================================

@dataclass(frozen=True)
class Obligation:
    """
    An action required to satisfy a policy.
    
    Examples:
    - notify_risk_officer
    - attach_explanation
    - human_review
    - quarterly_revalidation
    """
    obligation_id: str
    description: str
    due_by: Optional[str] = None  # ISO 8601 timestamp
    owner: Optional[str] = None   # Who is responsible
    evidence_required: bool = False
    
    def __str__(self) -> str:
        return f"Obligation({self.obligation_id}: {self.description})"


# ============================================================================
# PolicyProof (What Fired, Why)
# ============================================================================

@dataclass(frozen=True)
class PolicyProof:
    """
    Evidence that a policy was evaluated and what it determined.
    
    Auditability: Every decision includes proofs for all relevant policies.
    """
    policy_id: str
    policy_version: str
    condition: str  # Human-readable condition (e.g., "PSI > 0.2")
    outcome: Decision
    triggered: bool  # Did this policy fire?
    
    # NEW: Required fields for governance completeness
    threshold: float  # Policy threshold value
    observed_value: float  # Actual measured value
    evidence_node_ids: List[str] = field(default_factory=list)  # Provenance DAG nodes
    
    # Evidence (references to signals/artifacts)
    evidence: Dict[str, Any] = field(default_factory=dict)
    # Example: {"psi": 0.25, "threshold": 0.2, "signal_ref": "node_123"}
    
    # Rationale
    rationale: str = ""
    
    def __str__(self) -> str:
        status = "TRIGGERED" if self.triggered else "passed"
        return f"PolicyProof({self.policy_id}: {status} → {self.outcome.value})"
    
    def has_evidence_nodes(self) -> bool:
        """Check if policy proof has linked evidence nodes"""
        return len(self.evidence_node_ids) > 0


# ============================================================================
# Explanation (Claims + Evidence)
# ============================================================================

@dataclass(frozen=True)
class Explanation:
    """
    Audience-conditioned rationale with evidence links.
    
    Every claim references provenance evidence nodes.
    """
    explanation_id: str
    audience: str  # e.g., "customer", "regulator", "risk_officer"
    
    # Main explanation
    summary: str
    top_features: List[str] = field(default_factory=list)
    feature_importances: Dict[str, float] = field(default_factory=dict)
    
    # NEW: Required field for governance completeness
    evidence_node_ids: List[str] = field(default_factory=list)  # Provenance DAG nodes
    
    # Counterfactual (for adverse actions)
    counterfactual: Optional[str] = None
    counterfactual_changes: Optional[Dict[str, Any]] = None
    
    # Evidence links (provenance node IDs) - kept for backward compatibility
    evidence_refs: List[str] = field(default_factory=list)
    
    # Confidence
    confidence: float = 1.0  # 0-1
    
    def __str__(self) -> str:
        return f"Explanation({self.explanation_id} for {self.audience})"
    
    def has_evidence(self) -> bool:
        """Check if explanation is backed by provenance evidence"""
        return len(self.evidence_node_ids) > 0 or len(self.evidence_refs) > 0


# ============================================================================
# CostReport (Resource Usage)
# ============================================================================

@dataclass(frozen=True)
class CostReport:
    """
    Runtime cost, latency, and carbon tracking.
    
    FinOps uses this to issue advisories and enforce budget guards.
    """
    # Cost breakdown
    base_inference_cost: float  # USD (renamed from usd for clarity)
    shap_cost: float = 0.0
    dice_cost: float = 0.0
    provenance_cost: float = 0.0
    
    # Latency (milliseconds)
    total_latency_ms: float = 0.0
    
    # NEW: Carbon emissions tracking (grams CO2 equivalent)
    carbon_g: float = 0.0  # Renamed from gco2e to match existing code
    gco2e: float = 0.0  # Alias for backward compatibility
    
    # CPU time for carbon calculation
    cpu_seconds: float = 0.0
    
    # Advisories
    advisories: List[str] = field(default_factory=list)
    # e.g., ["Downshift SHAP to approximation", "Budget at 90%"]
    
    @property
    def total_cost(self) -> float:
        return (self.base_inference_cost + self.shap_cost + 
                self.dice_cost + self.provenance_cost)
    
    @property
    def usd(self) -> float:
        """Alias for backward compatibility"""
        return self.total_cost
    
    def __str__(self) -> str:
        return f"CostReport(${self.total_cost:.4f}, {self.total_latency_ms:.1f}ms, {self.carbon_g:.3f}gCO2e)"


# ============================================================================
# Arbitration (Conflict Resolution)
# ============================================================================

@dataclass(frozen=True)
class Arbitration:
    """
    Resolution of conflicts between agents.
    Records which agent won and why, with full audit trail.
    
    Used when agents disagree on decisions (e.g., Compliance says DENY, Cost says ALLOW).
    Priority hierarchy: Compliance > Safety > Cost > Latency
    """
    rule: str  # Arbitration rule applied (e.g., "compliance_override")
    winners: List[str]  # Agents whose decisions were upheld
    losers: List[str]  # Agents whose decisions were overridden
    reason: str  # Human-readable justification
    conflict_type: str = "multi_agent_conflict"  # Type of conflict resolved
    original_decisions: Dict[str, str] = field(default_factory=dict)  # {agent: decision}
    final_decision: Optional[str] = None  # Final arbitrated decision
    timestamp: str = ""  # ISO 8601 timestamp
    evidence_node_id: Optional[str] = None  # Link to arbitration node in provenance DAG
    
    def __str__(self) -> str:
        return f"Arbitration({self.rule}: {', '.join(self.winners)} > {', '.join(self.losers)})"


# Agent priority for consensus (highest priority first)
AGENT_PRIORITY = {
    "compliance": 1,  # Compliance always wins
    "safety": 2,      # Safety second
    "cost": 3,        # Cost third
    "latency": 4      # Latency last
}


def policy_weighted_consensus(
    agent_decisions: Dict[str, Decision],
    agent_confidences: Optional[Dict[str, float]] = None
) -> tuple[Decision, Optional[Arbitration]]:
    """
    Resolve conflicts between agent decisions using priority hierarchy.
    
    Rules:
    - Compliance > Safety > Cost > Latency
    - If Compliance says DENY or HOLD, that decision wins
    - If no conflicts, return majority vote
    
    Args:
        agent_decisions: {agent_name: Decision}
        agent_confidences: {agent_name: confidence_score} (optional)
        
    Returns:
        (final_decision, arbitration_record_or_none)
    """
    # Check if all agents agree
    unique_decisions = set(agent_decisions.values())
    if len(unique_decisions) == 1:
        return list(unique_decisions)[0], None
    
    # Sort agents by priority
    sorted_agents = sorted(
        agent_decisions.keys(),
        key=lambda a: AGENT_PRIORITY.get(a.lower(), 999)
    )
    
    # Find highest priority agent with DENY or HOLD
    for agent in sorted_agents:
        decision = agent_decisions[agent]
        if decision in [Decision.DENY, Decision.HOLD]:
            # This agent overrides others
            losers = [a for a in agent_decisions if a != agent]
            
            arbitration = Arbitration(
                rule=f"{agent}_override",
                winners=[agent],
                losers=losers,
                reason=f"{agent.title()} agent blocked approval (priority hierarchy)",
                conflict_type="multi_agent_conflict",
                original_decisions={k: v.value for k, v in agent_decisions.items()},
                final_decision=decision.value,
                timestamp=datetime.utcnow().isoformat()
            )
            return decision, arbitration
    
    # All agents approve but with different confidences - weighted vote
    # Use highest priority agent's decision
    winning_agent = sorted_agents[0]
    winning_decision = agent_decisions[winning_agent]
    
    # Only create arbitration if there was actual disagreement
    if len(unique_decisions) > 1:
        arbitration = Arbitration(
            rule="priority_weighted",
            winners=[winning_agent],
            losers=[a for a in sorted_agents[1:] if agent_decisions[a] != winning_decision],
            reason=f"Priority hierarchy: {winning_agent} has highest priority",
            conflict_type="confidence_weighted",
            original_decisions={k: v.value for k, v in agent_decisions.items()},
            final_decision=winning_decision.value,
            timestamp=datetime.utcnow().isoformat()
        )
        return winning_decision, arbitration
    
    return winning_decision, None


# ============================================================================
# GovernanceArtifact (What Gets Recorded)
# ============================================================================

@dataclass
class GovernanceArtifact:
    """
    The single source of truth for audits.
    
    Ties action, reasoning, and evidence into a sealed record.
    """
    episode_id: str
    timestamp: str
    
    # References (not raw data)
    inputs_ref: str
    model_version: str
    workflow: str
    
    # Signals
    signals: Dict[str, Any]
    
    # Policy evaluation
    policy_proofs: List[PolicyProof]
    
    # Explanation (if required)
    explanation_ref: Optional[str]
    
    # Cost tracking
    cost_report: CostReport
    
    # Final outcome
    outcome: Decision
    obligations: List[Obligation]
    
    # NEW: Arbitration record (if conflicts occurred)
    arbitration: Optional[Arbitration] = None
    
    # Seal (cryptographic integrity)
    seal: Dict[str, Any] = field(default_factory=dict)
    # {"hash": "sha256...", "sealed_at": "2025-10-18T...", "sealed_by": "orchestrator"}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict."""
        artifact_dict = {
            "episode_id": self.episode_id,
            "timestamp": self.timestamp,
            "inputs_ref": self.inputs_ref,
            "model_version": self.model_version,
            "workflow": self.workflow,
            "signals": self.signals,
            "policy_proofs": [
                {
                    "policy_id": p.policy_id,
                    "outcome": p.outcome.value,
                    "triggered": p.triggered,
                    "threshold": p.threshold,
                    "observed_value": p.observed_value,
                    "evidence_node_ids": p.evidence_node_ids,
                    "evidence": p.evidence
                }
                for p in self.policy_proofs
            ],
            "explanation_ref": self.explanation_ref,
            "cost_report": {
                "total_cost": self.cost_report.total_cost,
                "latency_ms": self.cost_report.total_latency_ms,
                "carbon_g": self.cost_report.carbon_g,
                "cpu_seconds": self.cost_report.cpu_seconds
            },
            "outcome": self.outcome.value,
            "obligations": [
                {"id": o.obligation_id, "description": o.description}
                for o in self.obligations
            ],
            "seal": self.seal
        }
        
        # Add arbitration if present
        if self.arbitration:
            artifact_dict["arbitration"] = {
                "rule": self.arbitration.rule,
                "winners": self.arbitration.winners,
                "losers": self.arbitration.losers,
                "reason": self.arbitration.reason,
                "final_decision": self.arbitration.final_decision
            }
        
        return artifact_dict


# ============================================================================
# Agent Protocol (Interface)
# ============================================================================

class AACPAgent:
    """
    Base protocol for AACP agents.
    
    All agents implement:
    - evaluate(ctx): Analyze and make decisions
    - report(ctx): Generate structured output
    """
    
    def evaluate(self, ctx: EpisodeContext) -> Dict[str, Any]:
        """
        Evaluate based on current context.
        
        Returns:
            Dict with agent-specific outputs
        """
        raise NotImplementedError
    
    def report(self, ctx: EpisodeContext) -> str:
        """
        Generate human-readable report.
        
        Returns:
            Markdown-formatted report
        """
        raise NotImplementedError


# ============================================================================
# Example Usage
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  AACP CONTRACTS - EXAMPLE USAGE")
    print("=" * 70)
    
    # Create episode context
    ctx = EpisodeContext(
        episode_id="ep_20251018_001",
        timestamp="2025-10-18T14:30:00Z",
        model_version="v1.2.3",
        workflow="credit_risk",
        inputs_ref="inputs_abc123",
        signals={"psi": 0.15, "shap_summary": {"age": 0.03}}
    )
    
    print(f"\n📋 Episode: {ctx.episode_id}")
    print(f"   Workflow: {ctx.workflow}")
    print(f"   Model: {ctx.model_version}")
    
    # Example policy proof
    proof = PolicyProof(
        policy_id="P1_drift",
        policy_version="1.0",
        condition="PSI > 0.2",
        outcome=Decision.ALLOW,
        triggered=False,
        evidence={"psi": 0.15, "threshold": 0.2}
    )
    print(f"\n✅ {proof}")
    
    # Example obligation
    obligation = Obligation(
        obligation_id="OBL_001",
        description="Attach explanation for rejection",
        evidence_required=True
    )
    print(f"\n📌 {obligation}")
    
    # Example explanation
    explanation = Explanation(
        explanation_id="exp_001",
        audience="customer",
        summary="Credit declined due to insufficient income",
        top_features=["income", "debt_ratio", "employment_length"],
        counterfactual="Increase income by $15,000 to flip decision",
        confidence=0.85
    )
    print(f"\n💡 {explanation}")
    print(f"   Counterfactual: {explanation.counterfactual}")
    
    # Example cost report
    cost = CostReport(
        base_inference_cost=0.001,
        shap_cost=0.002,
        dice_cost=0.005,
        total_latency_ms=125.5,
        carbon_g=0.015
    )
    print(f"\n💰 {cost}")
    
    print("\n" + "=" * 70)
    print("✅ AACP CONTRACTS READY")
    print("=" * 70)
