"""
AACP Orchestrator Agent - Episode Coordinator
==============================================

Implements the AACP interaction protocol:
1. Intent → Open episode
2. Signals → Compute PSI, SHAP
3. Compliance → Evaluate policies
4. Explainability → Generate explanation (if required)
5. FinOps → Track cost/latency
6. Consensus → Apply ordering rule (Compliance > Safety > Cost > Latency)
7. Seal → Commit or escalate

Bounded Autonomy:
- Automate when safe (Decision.ALLOW)
- Escalate when uncertain (Decision.HOLD)
- Enforce obligations (Decision.ALLOW_WITH_OBLIGATIONS)
"""

from typing import Dict, Any, Optional
import yaml
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

from .contracts import (
    EpisodeContext, Decision, PolicyProof, Obligation,
    Explanation, CostReport, GovernanceArtifact
)


class OrchestratorAgent:
    """
    Coordinates AACP episode workflow.
    
    Responsibilities:
    - Open/close episodes
    - Invoke agents in sequence
    - Apply policy-weighted consensus
    - Seal governance artifacts
    """
    
    def __init__(self, policy_path: str = None):
        """Initialize orchestrator with policy registry."""
        if policy_path is None:
            policy_path = Path(__file__).parent.parent / "policies" / "policy_registry.yaml"
        
        with open(policy_path) as f:
            self.policy_registry = yaml.safe_load(f)
        
        # Episode counter
        self.episode_count = 0
    
    def _generate_episode_id(self) -> str:
        """Generate unique episode ID."""
        self.episode_count += 1
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        return f"ep_{timestamp}_{self.episode_count:04d}"
    
    def _compute_seal(self, artifact: Dict[str, Any]) -> Dict[str, Any]:
        """
        Compute cryptographic seal for episode.
        
        Returns:
            {"hash": "sha256...", "sealed_at": "...", "sealed_by": "orchestrator"}
        """
        # Create canonical JSON
        seal_data = {
            "episode_id": artifact["episode_id"],
            "timestamp": artifact["timestamp"],
            "outcome": artifact["outcome"],
            "policy_proofs": artifact["policy_proofs"],
            "cost": artifact["cost_report"]["total_cost"]
        }
        
        canonical = json.dumps(seal_data, sort_keys=True, separators=(',', ':'))
        hash_digest = hashlib.sha256(canonical.encode('utf-8')).hexdigest()
        
        return {
            "hash": hash_digest,
            "sealed_at": datetime.now(timezone.utc).isoformat(),
            "sealed_by": "orchestrator_v1"
        }
    
    def _apply_consensus(self, policy_proofs: list) -> Decision:
        """
        Apply policy-weighted consensus.
        
        Ordering: Compliance > Safety > Cost > Latency
        
        Rules:
        1. If any policy says DENY → DENY
        2. If any policy says HOLD → HOLD
        3. If any policy says ALLOW_WITH_OBLIGATIONS → ALLOW_WITH_OBLIGATIONS
        4. Otherwise → ALLOW
        """
        if not policy_proofs:
            return Decision.ALLOW
        
        decisions = [p.outcome for p in policy_proofs if p.triggered]
        
        if Decision.DENY in decisions:
            return Decision.DENY
        elif Decision.HOLD in decisions:
            return Decision.HOLD
        elif Decision.ALLOW_WITH_OBLIGATIONS in decisions:
            return Decision.ALLOW_WITH_OBLIGATIONS
        else:
            return Decision.ALLOW
    
    def orchestrate(
        self,
        customer_data: Dict[str, Any],
        prediction: Dict[str, Any],
        model_version: str = "v1.0.0"
    ) -> GovernanceArtifact:
        """
        Orchestrate full AACP episode.
        
        Args:
            customer_data: Input features
            prediction: Model prediction {"decision": str, "probability": float}
            model_version: Model version identifier
            
        Returns:
            GovernanceArtifact with sealed decision
        """
        # 1. Open episode
        episode_id = self._generate_episode_id()
        timestamp = datetime.now(timezone.utc).isoformat()
        
        print(f"\n{'='*70}")
        print(f"  AACP EPISODE: {episode_id}")
        print(f"{'='*70}")
        
        # 2. Compute signals (simplified - would use real PSI/SHAP)
        signals = {
            "psi_summary": 0.15,  # Placeholder
            "shap_summary": {
                "age": 0.03,
                "duration": 0.25,
                "credit_amount": 0.18
            }
        }
        print(f"\n📊 Signals computed:")
        print(f"   PSI: {signals['psi_summary']:.3f}")
        print(f"   Top SHAP features: {list(signals['shap_summary'].keys())}")
        
        # 3. Compliance evaluation (simplified)
        from .compliance import ComplianceAgent
        compliance_agent = ComplianceAgent()
        
        context = {
            'psi_score': signals['psi_summary'],
            'shap_values': signals['shap_summary'],
            'decision': prediction['decision'],
            'explanation': None  # Will be filled if required
        }
        
        policy_results = compliance_agent.evaluate_all(context)
        
        # Convert to PolicyProof objects
        policy_proofs = []
        obligations = []
        
        for result in policy_results:
            # Determine if triggered
            triggered = result['outcome'] == 'fail'
            outcome = Decision.HOLD if triggered else Decision.ALLOW
            
            proof = PolicyProof(
                policy_id=result['policy_id'],
                policy_version="1.0",
                condition=f"Policy {result['policy_id']} condition",
                outcome=outcome,
                triggered=triggered,
                evidence=result.get('evidence', {}),
                rationale=result.get('reason', 'Policy passed')
            )
            policy_proofs.append(proof)
            
            # Add obligations if triggered
            if triggered and 'action' in result:
                obligation = Obligation(
                    obligation_id=f"OBL_{result['policy_id']}",
                    description=result['action']
                )
                obligations.append(obligation)
        
        print(f"\n⚖️  Compliance evaluated:")
        for proof in policy_proofs:
            status = "🔴 TRIGGERED" if proof.triggered else "🟢 passed"
            print(f"   {proof.policy_id}: {status}")
        
        # 4. Apply consensus
        final_decision = self._apply_consensus(policy_proofs)
        print(f"\n🎯 Consensus: {final_decision.value}")
        
        # 5. Explainability (if required)
        explanation_ref = None
        if final_decision in [Decision.DENY, Decision.HOLD] or prediction['decision'] == 'reject':
            # Generate explanation
            explanation = Explanation(
                explanation_id=f"exp_{episode_id}",
                audience="customer",
                summary=f"Decision: {prediction['decision']} (probability: {prediction['probability']:.2%})",
                top_features=list(signals['shap_summary'].keys())[:3],
                feature_importances=signals['shap_summary'],
                counterfactual="Improve credit amount or reduce duration",
                confidence=0.85
            )
            explanation_ref = explanation.explanation_id
            print(f"\n💡 Explanation generated: {explanation_ref}")
            
            # Update obligations
            context['explanation'] = {
                'top_features': explanation.top_features,
                'counterfactual': explanation.counterfactual
            }
            
            # Re-check P3 with explanation
            p3_result = compliance_agent.check_p3_explanation(
                prediction['decision'],
                context['explanation']
            )
            if p3_result['outcome'] == 'fail':
                final_decision = Decision.HOLD
                print(f"   ⚠️  P3 failed: {p3_result['reason']}")
        
        # 6. FinOps tracking
        from .finops import FinOpsAgent
        finops_agent = FinOpsAgent()
        
        cost_info = finops_agent.track_inference({
            'shap_computed': True,
            'counterfactual_generated': explanation_ref is not None
        })
        
        cost_report = CostReport(
            base_inference_cost=cost_info['base_cost'],
            shap_cost=cost_info['shap_cost'],
            dice_cost=cost_info['dice_cost'],
            total_latency_ms=125.5,  # Placeholder
            carbon_g=0.015  # Placeholder
        )
        
        print(f"\n💰 Cost: ${cost_report.total_cost:.6f}")
        
        # 7. Create governance artifact
        artifact = GovernanceArtifact(
            episode_id=episode_id,
            timestamp=timestamp,
            inputs_ref=f"inputs_{episode_id}",
            model_version=model_version,
            workflow="credit_risk",
            signals=signals,
            policy_proofs=policy_proofs,
            explanation_ref=explanation_ref,
            cost_report=cost_report,
            outcome=final_decision,
            obligations=obligations,
            seal={}  # Will be computed below
        )
        
        # 8. Seal artifact
        artifact_dict = artifact.to_dict()
        seal = self._compute_seal(artifact_dict)
        artifact.seal = seal
        
        print(f"\n🔒 Episode sealed: {seal['hash'][:16]}...")
        print(f"{'='*70}\n")
        
        return artifact
    
    def get_governance_summary(self, artifact: GovernanceArtifact) -> str:
        """Generate human-readable summary of governance artifact."""
        lines = [
            f"Episode: {artifact.episode_id}",
            f"Outcome: {artifact.outcome.value}",
            f"Policies evaluated: {len(artifact.policy_proofs)}",
            f"Obligations: {len(artifact.obligations)}",
            f"Cost: ${artifact.cost_report.total_cost:.4f}",
            f"Sealed: {artifact.seal['sealed_at']}"
        ]
        return "\n".join(lines)


if __name__ == "__main__":
    print("=" * 70)
    print("  AACP ORCHESTRATOR - TEST")
    print("=" * 70)
    
    orchestrator = OrchestratorAgent()
    
    # Test episode
    customer_data = {"age": 35, "duration": 24, "credit_amount": 5000}
    prediction = {"decision": "approve", "probability": 0.75}
    
    artifact = orchestrator.orchestrate(customer_data, prediction)
    
    print("\n" + "=" * 70)
    print("  GOVERNANCE SUMMARY")
    print("=" * 70)
    print(orchestrator.get_governance_summary(artifact))
    print("=" * 70)
