"""
Provenance Agent - Audit trail tracking.
"""

from typing import Dict, Any
import sqlite3
from datetime import datetime
import json


class ProvenanceAgent:
    """
    Tracks audit trails for credit decisions.
    """
    
    def __init__(self, db_path: str = "provenance.db"):
        """Initialize provenance database."""
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        """Create audit trail tables."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_trail (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    customer_id TEXT,
                    decision TEXT NOT NULL,
                    model_version TEXT,
                    features TEXT,
                    prediction_proba REAL,
                    policy_results TEXT,
                    explanation TEXT
                )
            """)
    
    def log_decision(self, decision_data: Dict[str, Any]) -> int:
        """
        Log a credit decision.
        
        Args:
            decision_data: Decision details
            
        Returns:
            Audit trail ID
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """
                INSERT INTO audit_trail (
                    timestamp, customer_id, decision, model_version,
                    features, prediction_proba, policy_results, explanation
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    datetime.utcnow().isoformat(),
                    decision_data.get('customer_id'),
                    decision_data.get('decision'),
                    decision_data.get('model_version'),
                    json.dumps(decision_data.get('features', {})),
                    decision_data.get('prediction_proba'),
                    json.dumps(decision_data.get('policy_results', [])),
                    json.dumps(decision_data.get('explanation', {}))
                )
            )
            return cursor.lastrowid


if __name__ == "__main__":
    print("Provenance agent ready!")
