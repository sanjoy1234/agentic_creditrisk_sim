#!/bin/bash
# Launch AACP Dashboard
# Usage: ./launch_dashboard.sh

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║          AACP Interactive Dashboard Launcher              ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Check if we're in the right directory
if [ ! -f "agentic_creditrisk_sim/ui/console.py" ]; then
    echo "❌ Error: Must be run from AgenticAIWorkspace directory"
    echo ""
    echo "Solution:"
    echo "  cd /Users/sanjoyghosh/Documents/AgenticAIWorkspace"
    echo "  ./agentic_creditrisk_sim/launch_dashboard.sh"
    exit 1
fi

# Check if results exist
if [ ! -f "agentic_creditrisk_sim/results/simulation_results.csv" ]; then
    echo "⚠️  Warning: No simulation results found"
    echo ""
    echo "Running simulation first..."
    python3 -m agentic_creditrisk_sim.simulation.run_simulation --seed 42
    echo ""
fi

echo "🚀 Launching Streamlit dashboard..."
echo ""
echo "📊 Dashboard will open at: http://localhost:8501"
echo ""
echo "Press Ctrl+C to stop the dashboard"
echo ""
echo "─────────────────────────────────────────────────────────────"
echo ""

# Launch streamlit
streamlit run agentic_creditrisk_sim/ui/console.py
