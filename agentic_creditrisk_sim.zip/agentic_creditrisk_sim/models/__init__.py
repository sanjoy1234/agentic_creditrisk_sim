"""Models module for training and prediction."""
