"""
Prediction module for inference pipeline.
"""

import pickle
from pathlib import Path
import pandas as pd
import numpy as np


class CreditRiskPredictor:
    """Wrapper for credit risk prediction."""
    
    def __init__(self, model_path: str = None, encoder_path: str = None):
        """
        Initialize predictor.
        
        Args:
            model_path: Path to model.pkl
            encoder_path: Path to encoder.pkl
        """
        if model_path is None:
            model_path = Path(__file__).parent / "model.pkl"
        if encoder_path is None:
            encoder_path = Path(__file__).parent / "encoder.pkl"
        
        # Load model
        with open(model_path, 'rb') as f:
            self.model = pickle.load(f)
        
        # Load encoder
        with open(encoder_path, 'rb') as f:
            self.encoder = pickle.load(f)
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        Predict credit risk.
        
        Args:
            X: DataFrame with features
            
        Returns:
            Array of predictions (0=bad, 1=good)
        """
        X_transformed = self.encoder.transform(X)
        return self.model.predict(X_transformed)
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """
        Predict credit risk probabilities.
        
        Args:
            X: DataFrame with features
            
        Returns:
            Array of probabilities (n_samples, 2)
        """
        X_transformed = self.encoder.transform(X)
        return self.model.predict_proba(X_transformed)


if __name__ == "__main__":
    print("Prediction module ready!")
