"""
Agentic Credit Risk Simulation - Model Training
================================================

Trains a GradientBoostingClassifier on the German Credit dataset.

Dataset: OpenML ID 31
Features: 20 (mix of categorical and numerical)
Target: class (1=good credit, 2=bad credit)
Size: 1000 samples

Output:
- models/model.pkl: Trained GradientBoostingClassifier
- models/encoder.pkl: OneHotEncoder for categorical features
- data/german_credit.csv: Raw dataset
"""

import pickle
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.metrics import classification_report, roc_auc_score
import openml


def download_german_credit() -> pd.DataFrame:
    """
    Download German Credit dataset from OpenML.
    
    Returns:
        DataFrame with features and target
    """
    print("📥 Downloading German Credit dataset (OpenML ID: 31)...")
    dataset = openml.datasets.get_dataset(31)
    X, y, categorical_indicator, attribute_names = dataset.get_data(
        target=dataset.default_target_attribute,
        dataset_format="dataframe"
    )
    
    # Combine features and target
    data = X.copy()
    data['target'] = y
    
    # Convert target to binary (1=good, 0=bad)
    # OpenML returns: 'good' and 'bad' strings
    data['target'] = (data['target'] == 'good').astype(int)
    
    print(f"✅ Dataset downloaded: {data.shape[0]} samples, {data.shape[1]-1} features")
    print(f"   • Good credit: {data['target'].sum()}")
    print(f"   • Bad credit: {(1 - data['target']).sum()}")
    return data


def save_dataset(data: pd.DataFrame, path: str) -> None:
    """Save dataset to CSV."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(path, index=False)
    print(f"✅ Dataset saved to {path}")


def preprocess_data(data: pd.DataFrame):
    """
    Preprocess German Credit dataset.
    
    Returns:
        X_train, X_test, y_train, y_test, preprocessor
    """
    print("\n🔧 Preprocessing data...")
    
    # Separate features and target
    X = data.drop('target', axis=1)
    y = data['target']
    
    # Identify categorical and numerical columns
    categorical_cols = X.select_dtypes(include=['object', 'category']).columns.tolist()
    numerical_cols = X.select_dtypes(include=['int64', 'float64']).columns.tolist()
    
    print(f"  • Categorical features: {len(categorical_cols)}")
    print(f"  • Numerical features: {len(numerical_cols)}")
    
    # Create preprocessor
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_cols),
            ('num', 'passthrough', numerical_cols)
        ],
        verbose_feature_names_out=False
    )
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"  • Train set: {X_train.shape[0]} samples")
    print(f"  • Test set: {X_test.shape[0]} samples")
    
    # Fit preprocessor on training data
    X_train_transformed = preprocessor.fit_transform(X_train)
    X_test_transformed = preprocessor.transform(X_test)
    
    print(f"  • Transformed features: {X_train_transformed.shape[1]} (after one-hot encoding)")
    
    return X_train_transformed, X_test_transformed, y_train, y_test, preprocessor


def train_model(X_train, y_train):
    """
    Train GradientBoostingClassifier.
    
    Returns:
        Trained model
    """
    print("\n🚂 Training GradientBoostingClassifier...")
    
    model = GradientBoostingClassifier(
        n_estimators=100,
        learning_rate=0.1,
        max_depth=3,
        random_state=42,
        verbose=0
    )
    
    model.fit(X_train, y_train)
    
    print("✅ Model trained!")
    return model


def evaluate_model(model, X_test, y_test):
    """Evaluate model performance."""
    print("\n📊 Evaluating model...")
    
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    
    # Classification report
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=['Bad Credit', 'Good Credit']))
    
    # ROC-AUC
    auc = roc_auc_score(y_test, y_pred_proba)
    print(f"ROC-AUC Score: {auc:.4f}")
    
    # Feature importance (top 10)
    if hasattr(model, 'feature_importances_'):
        importances = model.feature_importances_
        top_indices = np.argsort(importances)[-10:][::-1]
        print("\nTop 10 Feature Importances:")
        for idx in top_indices:
            print(f"  Feature {idx}: {importances[idx]:.4f}")


def save_artifacts(model, preprocessor):
    """Save model and preprocessor."""
    print("\n💾 Saving artifacts...")
    
    models_dir = Path(__file__).parent
    
    # Save model
    model_path = models_dir / "model.pkl"
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)
    print(f"✅ Model saved to {model_path}")
    
    # Save preprocessor
    encoder_path = models_dir / "encoder.pkl"
    with open(encoder_path, 'wb') as f:
        pickle.dump(preprocessor, f)
    print(f"✅ Encoder saved to {encoder_path}")


def main():
    """Main training pipeline."""
    print("=" * 70)
    print("  AGENTIC CREDIT RISK SIMULATION - MODEL TRAINING")
    print("=" * 70)
    
    # Download dataset
    data = download_german_credit()
    
    # Save dataset
    data_path = Path(__file__).parent.parent / "data" / "german_credit.csv"
    save_dataset(data, str(data_path))
    
    # Preprocess
    X_train, X_test, y_train, y_test, preprocessor = preprocess_data(data)
    
    # Train
    model = train_model(X_train, y_train)
    
    # Evaluate
    evaluate_model(model, X_test, y_test)
    
    # Save
    save_artifacts(model, preprocessor)
    
    print("\n" + "=" * 70)
    print("✅ TRAINING COMPLETE!")
    print("=" * 70)
    print("\nArtifacts created:")
    print("  • models/model.pkl")
    print("  • models/encoder.pkl")
    print("  • data/german_credit.csv")
    print("\nNext steps:")
    print("  1. Run simulation: make simulate")
    print("  2. Launch UI: make ui")


if __name__ == "__main__":
    main()
