"""
PII Tokenization
================
Tokenizes personally identifiable information (PII) using salted SHA256.

Ensures:
- No raw PII is stored in logs or artifacts
- Consistent tokenization with salt
- Regulator view hides non-essential columns
- Compliant with privacy regulations (GDPR, CCPA)

PII Fields:
- name, email, phone, ssn, address, account_number
- Any field marked as sensitive in schema
"""

import hashlib
import json
from typing import Dict, Any, List, Optional
from pathlib import Path


# Default salt (should be stored securely in production)
DEFAULT_SALT = "aacp_2025_salt_v1"

# PII field patterns
PII_FIELDS = {
    "name", "first_name", "last_name", "full_name",
    "email", "email_address",
    "phone", "phone_number", "mobile",
    "ssn", "social_security", "tax_id",
    "address", "street_address", "home_address",
    "account_number", "account_id", "customer_id",
    "credit_card", "card_number",
    "passport", "drivers_license",
    "dob", "date_of_birth", "birthdate"
}


def tokenize_value(value: str, salt: str = DEFAULT_SALT) -> str:
    """
    Tokenize a single value using salted SHA256.
    
    Args:
        value: Raw value to tokenize
        salt: Salt string for hashing
        
    Returns:
        Hex-encoded hash (64 characters)
        
    Example:
        >>> tokenize_value("john.doe@example.com")
        'a7f3d8b9e2c1...'  # SHA256 hash
    """
    if not value:
        return ""
    
    salted = f"{salt}:{value}"
    return hashlib.sha256(salted.encode()).hexdigest()


def tokenize_record(
    record: Dict[str, Any],
    salt: str = DEFAULT_SALT,
    pii_fields: Optional[set] = None
) -> Dict[str, Any]:
    """
    Tokenize all PII fields in a record.
    
    Recursively processes nested dicts and lists.
    Non-PII fields are preserved as-is.
    
    Args:
        record: Input record dict
        salt: Salt for hashing
        pii_fields: Set of field names to tokenize (default: PII_FIELDS)
        
    Returns:
        Record with PII fields tokenized
        
    Example:
        >>> tokenize_record({"name": "John Doe", "age": 30})
        {"name": "a7f3d8b9e2c1...", "age": 30}
    """
    if pii_fields is None:
        pii_fields = PII_FIELDS
    
    tokenized = {}
    
    for key, value in record.items():
        # Check if this field is PII
        is_pii = any(pii_pattern in key.lower() for pii_pattern in pii_fields)
        
        if is_pii and isinstance(value, str):
            # Tokenize string PII
            tokenized[key] = tokenize_value(value, salt)
        elif isinstance(value, dict):
            # Recursively tokenize nested dicts
            tokenized[key] = tokenize_record(value, salt, pii_fields)
        elif isinstance(value, list):
            # Process lists
            tokenized[key] = [
                tokenize_record(item, salt, pii_fields) if isinstance(item, dict)
                else tokenize_value(item, salt) if is_pii and isinstance(item, str)
                else item
                for item in value
            ]
        else:
            # Preserve non-PII values
            tokenized[key] = value
    
    return tokenized


def detokenize_record(
    tokenized_record: Dict[str, Any],
    pii_mapping: Dict[str, str]
) -> Dict[str, Any]:
    """
    Detokenize a record using a pre-computed mapping.
    
    WARNING: Only use for authorized access (e.g., regulator review).
    
    Args:
        tokenized_record: Record with tokenized PII
        pii_mapping: {token: original_value} mapping
        
    Returns:
        Record with original PII values restored
    """
    detokenized = {}
    
    for key, value in tokenized_record.items():
        if isinstance(value, str) and value in pii_mapping:
            # Restore original value
            detokenized[key] = pii_mapping[value]
        elif isinstance(value, dict):
            # Recursively detokenize nested dicts
            detokenized[key] = detokenize_record(value, pii_mapping)
        elif isinstance(value, list):
            detokenized[key] = [
                detokenize_record(item, pii_mapping) if isinstance(item, dict)
                else pii_mapping.get(item, item)
                for item in value
            ]
        else:
            detokenized[key] = value
    
    return detokenized


def scan_for_raw_pii(
    data: Any,
    pii_patterns: Optional[List[str]] = None
) -> List[str]:
    """
    Scan data structure for potential raw PII.
    
    Returns list of field paths that might contain raw PII.
    Used for validation after tokenization.
    
    Args:
        data: Data structure to scan (dict, list, or primitive)
        pii_patterns: Patterns to check (default: email-like, phone-like, SSN-like)
        
    Returns:
        List of field paths with potential raw PII
    """
    if pii_patterns is None:
        # Simple patterns for common PII formats
        pii_patterns = [
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',  # Email
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',  # Phone
            r'\b\d{3}-\d{2}-\d{4}\b',  # SSN
        ]
    
    import re
    
    violations = []
    
    def _scan(obj, path=""):
        if isinstance(obj, dict):
            for key, value in obj.items():
                _scan(value, f"{path}.{key}" if path else key)
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                _scan(item, f"{path}[{i}]")
        elif isinstance(obj, str):
            # Check if string matches PII patterns
            for pattern in pii_patterns:
                if re.search(pattern, obj):
                    violations.append(path)
                    break
    
    _scan(data)
    return violations


def get_regulator_view_columns() -> List[str]:
    """
    Get list of columns safe for regulator view.
    
    Excludes:
    - Raw PII fields
    - Internal debugging columns
    - Sensitive cost breakdowns
    
    Returns:
        List of column names
    """
    return [
        "sample_id",
        "episode_id",
        "decision",
        "outcome",
        "model_version",
        "timestamp",
        "policy_proofs",
        "policies_passed",
        "p1_triggered",
        "p2_triggered",
        "p3_triggered",
        "has_explanation",
        "explanation_ref",
        "seal_hash",
        "arbitration_count",
        "governance_completeness",
        "total_cost",
        "carbon_g",
        "latency_ms"
    ]


def apply_regulator_view(df: 'pandas.DataFrame') -> 'pandas.DataFrame':
    """
    Filter dataframe to regulator-safe columns.
    
    Args:
        df: Full dataframe
        
    Returns:
        Filtered dataframe with only regulator-safe columns
    """
    regulator_cols = get_regulator_view_columns()
    available_cols = [col for col in regulator_cols if col in df.columns]
    return df[available_cols]


def create_pii_mapping(
    records: List[Dict[str, Any]],
    salt: str = DEFAULT_SALT
) -> Dict[str, str]:
    """
    Create bidirectional PII mapping for detokenization.
    
    WARNING: Store mapping securely, separate from tokenized data.
    
    Args:
        records: List of records with raw PII
        salt: Salt for tokenization
        
    Returns:
        {token: original_value} mapping
    """
    mapping = {}
    
    def _extract_pii(obj):
        if isinstance(obj, dict):
            for key, value in obj.items():
                is_pii = any(pii_pattern in key.lower() for pii_pattern in PII_FIELDS)
                if is_pii and isinstance(value, str) and value:
                    token = tokenize_value(value, salt)
                    mapping[token] = value
                elif isinstance(value, (dict, list)):
                    _extract_pii(value)
        elif isinstance(obj, list):
            for item in obj:
                _extract_pii(item)
    
    for record in records:
        _extract_pii(record)
    
    return mapping


def save_pii_mapping(
    mapping: Dict[str, str],
    output_path: str = ".secrets/pii_mapping.json"
) -> Path:
    """
    Save PII mapping to secure location.
    
    Args:
        mapping: PII mapping dict
        output_path: Output file path (should be in .gitignore)
        
    Returns:
        Path to saved file
    """
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(path, 'w') as f:
        json.dump(mapping, f, indent=2)
    
    # Set restrictive permissions (Unix only)
    try:
        path.chmod(0o600)  # rw-------
    except Exception:
        pass
    
    return path


def load_pii_mapping(mapping_path: str = ".secrets/pii_mapping.json") -> Dict[str, str]:
    """
    Load PII mapping from secure location.
    
    Args:
        mapping_path: Path to mapping file
        
    Returns:
        PII mapping dict
    """
    path = Path(mapping_path)
    
    if not path.exists():
        return {}
    
    with open(path, 'r') as f:
        return json.load(f)


# ============================================================================
# Example Usage
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  PII TOKENIZATION - EXAMPLE USAGE")
    print("=" * 70)
    
    # Example record with PII
    raw_record = {
        "name": "John Doe",
        "email": "john.doe@example.com",
        "phone": "555-123-4567",
        "age": 35,
        "income": 75000,
        "address": {
            "street": "123 Main St",
            "city": "Springfield",
            "zip": "12345"
        }
    }
    
    print("\n📄 Original record:")
    print(json.dumps(raw_record, indent=2))
    
    # Tokenize
    tokenized = tokenize_record(raw_record)
    print("\n🔒 Tokenized record:")
    print(json.dumps(tokenized, indent=2))
    
    # Scan for raw PII
    violations = scan_for_raw_pii(tokenized)
    print(f"\n🔍 PII scan: {len(violations)} violations found")
    if violations:
        for v in violations:
            print(f"   ⚠️  {v}")
    else:
        print("   ✅ No raw PII detected")
    
    # Create mapping for detokenization
    mapping = create_pii_mapping([raw_record])
    print(f"\n🗝️  Created mapping with {len(mapping)} entries")
    
    # Detokenize (authorized access only)
    detokenized = detokenize_record(tokenized, mapping)
    print("\n🔓 Detokenized record:")
    print(json.dumps(detokenized, indent=2))
    
    # Verify match
    matches = raw_record == detokenized
    print(f"\n✅ Round-trip verification: {matches}")
    
    print("\n" + "=" * 70)
    print("✅ PII TOKENIZATION READY")
    print("=" * 70)
