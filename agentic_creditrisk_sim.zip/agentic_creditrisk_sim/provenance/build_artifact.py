"""
Artifact Builder
================
Builds complete governance artifacts from episode provenance data.

Creates JSON artifacts containing:
- Episode metadata
- Input references (tokenized)
- Model version
- Signals (PSI, SHAP summaries)
- Policy proofs with evidence links
- Explanation references
- Cost reports (USD + carbon)
- Arbitration records (if conflicts occurred)
- Cryptographic seal

Artifacts are persisted to: runs/artifacts/{episode_id}.json
"""

import json
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

from . import store
from ..agents.contracts import (
    GovernanceArtifact,
    PolicyProof,
    Explanation,
    CostReport,
    Obligation,
    Decision,
    Arbitration
)


def build_episode_artifact(
    episode_id: str,
    inputs_ref: str,
    model_version: str,
    signals: Dict[str, Any],
    policy_proofs: list,
    explanation_ref: Optional[str],
    cost_report: CostReport,
    outcome: Decision,
    obligations: list = None,
    arbitration: Optional[Arbitration] = None,
    workflow: str = "credit_risk"
) -> Dict[str, Any]:
    """
    Build complete governance artifact from episode data.
    
    Args:
        episode_id: Unique episode identifier
        inputs_ref: Reference to input data (tokenized)
        model_version: Model version used
        signals: Signal summaries (PSI, SHAP, etc.)
        policy_proofs: List of PolicyProof objects
        explanation_ref: Reference to explanation (if generated)
        cost_report: CostReport object
        outcome: Final Decision
        obligations: List of Obligation objects
        arbitration: Arbitration record (if conflicts occurred)
        workflow: Workflow type (default: credit_risk)
        
    Returns:
        Complete artifact dict with all metadata and seal
        
    Raises:
        ValueError: If episode cannot be sealed (missing evidence)
    """
    # Get all evidence nodes for this episode
    nodes = store.get_episode_nodes(episode_id)
    
    # Seal the episode
    try:
        seal_hash = store.seal_episode(episode_id)
        sealed_at = datetime.utcnow().isoformat()
    except (ValueError, RuntimeError) as e:
        # Episode cannot be sealed - return partial artifact with error
        return {
            "episode_id": episode_id,
            "error": f"Cannot seal episode: {str(e)}",
            "sealed": False,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    # Build complete artifact
    artifact = {
        "episode_id": episode_id,
        "timestamp": datetime.utcnow().isoformat(),
        "inputs_ref": inputs_ref,
        "model_version": model_version,
        "workflow": workflow,
        
        # Signals
        "signals": {
            "psi_summary": signals.get("psi", 0.0),
            "shap_summary": signals.get("shap_summary", {}),
            **signals  # Include any additional signals
        },
        
        # Policy proofs with evidence links
        "policy_proofs": [
            {
                "policy_id": p.policy_id if hasattr(p, 'policy_id') else p.get('policy_id'),
                "policy_version": p.policy_version if hasattr(p, 'policy_version') else p.get('policy_version', '1.0'),
                "threshold": p.threshold if hasattr(p, 'threshold') else p.get('threshold', 0.0),
                "observed_value": p.observed_value if hasattr(p, 'observed_value') else p.get('observed_value', 0.0),
                "triggered": p.triggered if hasattr(p, 'triggered') else p.get('triggered', False),
                "evidence_node_ids": p.evidence_node_ids if hasattr(p, 'evidence_node_ids') else p.get('evidence_node_ids', []),
                "outcome": p.outcome.value if hasattr(p.outcome, 'value') else str(p.outcome) if hasattr(p, 'outcome') else p.get('outcome', 'ALLOW')
            }
            for p in (policy_proofs or [])
        ],
        
        # Explanation reference
        "explanation_ref": explanation_ref,
        
        # Cost report with carbon
        "cost_report": {
            "usd": cost_report.usd if hasattr(cost_report, 'usd') else cost_report.total_cost,
            "gco2e": cost_report.gco2e if hasattr(cost_report, 'gco2e') else cost_report.carbon_g,
            "cpu_seconds": cost_report.cpu_seconds if hasattr(cost_report, 'cpu_seconds') else 0.0,
            "latency_ms": cost_report.total_latency_ms if hasattr(cost_report, 'total_latency_ms') else 0.0,
            "breakdown": {
                "base": cost_report.base_inference_cost if hasattr(cost_report, 'base_inference_cost') else 0.0,
                "shap": cost_report.shap_cost if hasattr(cost_report, 'shap_cost') else 0.0,
                "dice": cost_report.dice_cost if hasattr(cost_report, 'dice_cost') else 0.0,
                "provenance": cost_report.provenance_cost if hasattr(cost_report, 'provenance_cost') else 0.0
            }
        },
        
        # Outcome and obligations
        "outcome": outcome.value if hasattr(outcome, 'value') else str(outcome),
        "obligations": [
            {
                "id": o.obligation_id if hasattr(o, 'obligation_id') else o.get('obligation_id'),
                "description": o.description if hasattr(o, 'description') else o.get('description'),
                "due_by": o.due_by if hasattr(o, 'due_by') else o.get('due_by')
            }
            for o in (obligations or [])
        ],
        
        # Arbitration (if conflicts occurred)
        "arbitration": None,
        
        # Cryptographic seal
        "seal": {
            "hash": seal_hash,
            "sealed_at": sealed_at,
            "sealed_by": "orchestrator",
            "node_count": len(nodes)
        }
    }
    
    # Add arbitration if present
    if arbitration:
        artifact["arbitration"] = {
            "rule": arbitration.rule,
            "winners": arbitration.winners,
            "losers": arbitration.losers,
            "reason": arbitration.reason,
            "conflict_type": arbitration.conflict_type,
            "final_decision": arbitration.final_decision,
            "evidence_node_id": arbitration.evidence_node_id
        }
    
    return artifact


def persist_artifact(artifact: Dict[str, Any], output_dir: str = "runs/artifacts") -> Path:
    """
    Persist artifact to JSON file.
    
    Args:
        artifact: Artifact dict from build_episode_artifact
        output_dir: Output directory (default: runs/artifacts)
        
    Returns:
        Path to written file
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    episode_id = artifact["episode_id"]
    file_path = output_path / f"{episode_id}.json"
    
    with open(file_path, 'w') as f:
        json.dump(artifact, f, indent=2)
    
    return file_path


def load_artifact(episode_id: str, artifacts_dir: str = "runs/artifacts") -> Optional[Dict[str, Any]]:
    """
    Load artifact from JSON file.
    
    Args:
        episode_id: Episode identifier
        artifacts_dir: Artifacts directory
        
    Returns:
        Artifact dict or None if not found
    """
    file_path = Path(artifacts_dir) / f"{episode_id}.json"
    
    if not file_path.exists():
        return None
    
    with open(file_path, 'r') as f:
        return json.load(f)


def verify_artifact_integrity(artifact: Dict[str, Any]) -> tuple[bool, str]:
    """
    Verify artifact integrity by recomputing seal.
    
    Args:
        artifact: Artifact dict to verify
        
    Returns:
        (is_valid, message)
    """
    episode_id = artifact["episode_id"]
    expected_seal = artifact["seal"]["hash"]
    
    # Verify seal matches current provenance store
    is_valid = store.verify_seal(episode_id, expected_seal)
    
    if is_valid:
        return True, "Artifact seal is valid"
    else:
        return False, "Artifact seal does not match provenance store"


def validate_artifact_completeness(artifact: Dict[str, Any]) -> tuple[bool, list[str]]:
    """
    Validate that artifact has all required governance components.
    
    Checks:
    - Has policy proofs
    - Policy proofs have evidence_node_ids
    - If outcome=DENY, has explanation_ref
    - Has seal
    
    Args:
        artifact: Artifact dict to validate
        
    Returns:
        (is_complete, issues)
    """
    issues = []
    
    # Check policy proofs
    policy_proofs = artifact.get("policy_proofs", [])
    if not policy_proofs:
        issues.append("No policy proofs found")
    else:
        for proof in policy_proofs:
            if not proof.get("evidence_node_ids"):
                issues.append(f"Policy proof {proof.get('policy_id')} missing evidence_node_ids")
    
    # Check explanation for rejections
    outcome = artifact.get("outcome", "")
    if outcome in ["DENY", "deny", "reject", "REJECT"]:
        if not artifact.get("explanation_ref"):
            issues.append("Rejection without explanation_ref (P3 violation)")
    
    # Check seal
    if not artifact.get("seal", {}).get("hash"):
        issues.append("Artifact not sealed")
    
    return len(issues) == 0, issues


# ============================================================================
# Batch Processing
# ============================================================================

def build_and_persist_artifact(
    episode_id: str,
    **kwargs
) -> tuple[Dict[str, Any], Path]:
    """
    Build and persist artifact in one call.
    
    Args:
        episode_id: Episode identifier
        **kwargs: Arguments for build_episode_artifact
        
    Returns:
        (artifact, file_path)
    """
    artifact = build_episode_artifact(episode_id, **kwargs)
    file_path = persist_artifact(artifact)
    return artifact, file_path


def get_artifacts_summary(artifacts_dir: str = "runs/artifacts") -> Dict[str, Any]:
    """
    Get summary statistics for all artifacts in directory.
    
    Returns:
        {total_artifacts, sealed_count, with_explanation, with_arbitration}
    """
    artifacts_path = Path(artifacts_dir)
    
    if not artifacts_path.exists():
        return {
            "total_artifacts": 0,
            "sealed_count": 0,
            "with_explanation": 0,
            "with_arbitration": 0
        }
    
    artifact_files = list(artifacts_path.glob("*.json"))
    
    sealed_count = 0
    with_explanation = 0
    with_arbitration = 0
    
    for file_path in artifact_files:
        try:
            with open(file_path, 'r') as f:
                artifact = json.load(f)
                
            if artifact.get("seal", {}).get("hash"):
                sealed_count += 1
            if artifact.get("explanation_ref"):
                with_explanation += 1
            if artifact.get("arbitration"):
                with_arbitration += 1
        except Exception:
            continue
    
    return {
        "total_artifacts": len(artifact_files),
        "sealed_count": sealed_count,
        "with_explanation": with_explanation,
        "with_arbitration": with_arbitration
    }


# ============================================================================
# Example Usage
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  ARTIFACT BUILDER - EXAMPLE USAGE")
    print("=" * 70)
    
    from ..agents.contracts import CostReport, PolicyProof, Decision
    
    # Create episode with evidence nodes
    episode_id = "ep_20251018_artifact_test"
    
    # Attach evidence
    store.attach_artifact(episode_id, "signal", {"psi": 0.15})
    store.attach_artifact(episode_id, "policy_proof", {"policy_id": "P1", "passed": True})
    store.attach_artifact(episode_id, "explanation", {"summary": "Approved"})
    
    # Build artifact
    cost = CostReport(
        base_inference_cost=0.001,
        shap_cost=0.002,
        dice_cost=0.005,
        total_latency_ms=125.5,
        carbon_g=0.015,
        cpu_seconds=0.05
    )
    
    artifact = build_episode_artifact(
        episode_id=episode_id,
        inputs_ref="input_ref_123",
        model_version="v1.2.3",
        signals={"psi": 0.15},
        policy_proofs=[],
        explanation_ref="exp_123",
        cost_report=cost,
        outcome=Decision.ALLOW
    )
    
    print(f"\n✅ Built artifact: {episode_id}")
    print(f"   Seal: {artifact['seal']['hash'][:16]}...")
    print(f"   Nodes: {artifact['seal']['node_count']}")
    
    # Validate completeness
    is_complete, issues = validate_artifact_completeness(artifact)
    print(f"\n📋 Completeness: {is_complete}")
    if issues:
        for issue in issues:
            print(f"   ⚠️  {issue}")
    
    # Persist artifact
    file_path = persist_artifact(artifact, output_dir="/tmp/artifacts_test")
    print(f"\n💾 Persisted to: {file_path}")
    
    print("\n" + "=" * 70)
    print("✅ ARTIFACT BUILDER READY")
    print("=" * 70)
