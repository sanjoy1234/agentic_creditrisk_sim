"""
Provenance Store
================
Manages provenance DAG nodes and episode sealing with cryptographic integrity.

Key Concepts:
- Episodes contain multiple evidence nodes (artifacts)
- Each node has: id, kind, payload, timestamp
- Sealing creates SHA256 hash of all nodes (order-invariant)
- Sealed episodes are immutable and auditable
"""

import json
import hashlib
from typing import Dict, List, Any, Optional
from datetime import datetime
from pathlib import Path
import sqlite3


# In-memory storage for demonstration (production would use persistent DB)
_provenance_store: Dict[str, List[Dict[str, Any]]] = {}
_sealed_episodes: Dict[str, str] = {}


def attach_artifact(
    episode_id: str,
    kind: str,
    payload: Dict[str, Any],
    timestamp: Optional[str] = None
) -> str:
    """
    Attach an evidence artifact to an episode's provenance DAG.
    
    Args:
        episode_id: Unique episode identifier
        kind: Artifact type (e.g., "signal", "policy_proof", "explanation", "arbitration")
        payload: Artifact data (must be JSON-serializable)
        timestamp: ISO 8601 timestamp (defaults to now)
        
    Returns:
        evidence_id: Unique identifier for this artifact node
        
    Example:
        >>> attach_artifact("ep_001", "signal", {"psi": 0.15, "threshold": 0.2})
        'node_ep_001_0'
    """
    if episode_id not in _provenance_store:
        _provenance_store[episode_id] = []
    
    # Generate evidence node ID
    node_count = len(_provenance_store[episode_id])
    evidence_id = f"node_{episode_id}_{node_count}"
    
    # Create node
    node = {
        "evidence_id": evidence_id,
        "kind": kind,
        "payload": payload,
        "timestamp": timestamp or datetime.utcnow().isoformat(),
        "episode_id": episode_id
    }
    
    _provenance_store[episode_id].append(node)
    
    return evidence_id


def seal_episode(episode_id: str) -> str:
    """
    Seal an episode with cryptographic hash of all evidence nodes.
    
    The seal is order-invariant: sorting nodes by evidence_id before hashing
    ensures identical seal for same content regardless of insertion order.
    
    Args:
        episode_id: Episode to seal
        
    Returns:
        seal_hash: SHA256 hash of all nodes (hex string)
        
    Raises:
        ValueError: If episode has no evidence nodes
        RuntimeError: If episode is already sealed
        
    Example:
        >>> seal_episode("ep_001")
        'a3f5...7c2d'  # SHA256 hash
    """
    if episode_id not in _provenance_store:
        raise ValueError(f"Episode {episode_id} not found in provenance store")
    
    if episode_id in _sealed_episodes:
        raise RuntimeError(f"Episode {episode_id} is already sealed")
    
    nodes = _provenance_store[episode_id]
    if not nodes:
        raise ValueError(f"Cannot seal episode {episode_id} with no evidence nodes")
    
    # Sort nodes by evidence_id for order-invariance
    sorted_nodes = sorted(nodes, key=lambda n: n["evidence_id"])
    
    # Compute hash of sorted nodes
    nodes_json = json.dumps(sorted_nodes, sort_keys=True)
    seal_hash = hashlib.sha256(nodes_json.encode()).hexdigest()
    
    # Record seal
    _sealed_episodes[episode_id] = seal_hash
    
    return seal_hash


def get_episode_nodes(episode_id: str) -> List[Dict[str, Any]]:
    """
    Retrieve all evidence nodes for an episode.
    
    Args:
        episode_id: Episode identifier
        
    Returns:
        List of evidence nodes
    """
    return _provenance_store.get(episode_id, [])


def get_episode_seal(episode_id: str) -> Optional[str]:
    """
    Get seal hash for an episode (if sealed).
    
    Args:
        episode_id: Episode identifier
        
    Returns:
        Seal hash or None if not sealed
    """
    return _sealed_episodes.get(episode_id)


def is_sealed(episode_id: str) -> bool:
    """Check if episode is sealed."""
    return episode_id in _sealed_episodes


def verify_seal(episode_id: str, expected_seal: str) -> bool:
    """
    Verify that an episode's seal matches expected value.
    
    Recomputes seal from current nodes and compares.
    
    Args:
        episode_id: Episode to verify
        expected_seal: Expected seal hash
        
    Returns:
        True if seals match, False otherwise
    """
    if episode_id not in _provenance_store:
        return False
    
    # Recompute seal
    nodes = _provenance_store[episode_id]
    sorted_nodes = sorted(nodes, key=lambda n: n["evidence_id"])
    nodes_json = json.dumps(sorted_nodes, sort_keys=True)
    computed_seal = hashlib.sha256(nodes_json.encode()).hexdigest()
    
    return computed_seal == expected_seal


def get_node_by_id(evidence_id: str) -> Optional[Dict[str, Any]]:
    """
    Find a specific evidence node by ID.
    
    Args:
        evidence_id: Evidence node identifier
        
    Returns:
        Node data or None if not found
    """
    for episode_nodes in _provenance_store.values():
        for node in episode_nodes:
            if node["evidence_id"] == evidence_id:
                return node
    return None


def validate_evidence_nodes(evidence_node_ids: List[str]) -> tuple[bool, List[str]]:
    """
    Validate that all evidence node IDs exist in the store.
    
    Args:
        evidence_node_ids: List of evidence IDs to check
        
    Returns:
        (all_found, missing_ids)
    """
    missing = []
    for node_id in evidence_node_ids:
        if not get_node_by_id(node_id):
            missing.append(node_id)
    
    return len(missing) == 0, missing


def clear_episode(episode_id: str) -> None:
    """
    Clear an episode from the store (for testing).
    
    Args:
        episode_id: Episode to clear
    """
    if episode_id in _provenance_store:
        del _provenance_store[episode_id]
    if episode_id in _sealed_episodes:
        del _sealed_episodes[episode_id]


def get_store_stats() -> Dict[str, int]:
    """
    Get statistics about the provenance store.
    
    Returns:
        {total_episodes, total_nodes, sealed_episodes}
    """
    total_nodes = sum(len(nodes) for nodes in _provenance_store.values())
    return {
        "total_episodes": len(_provenance_store),
        "total_nodes": total_nodes,
        "sealed_episodes": len(_sealed_episodes)
    }


# ============================================================================
# Persistent Storage (SQLite for production)
# ============================================================================

def init_persistent_store(db_path: str = "provenance.db") -> None:
    """
    Initialize SQLite database for persistent provenance storage.
    
    Schema:
        episodes: (episode_id, seal_hash, sealed_at)
        nodes: (evidence_id, episode_id, kind, payload_json, timestamp)
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create tables
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS episodes (
            episode_id TEXT PRIMARY KEY,
            seal_hash TEXT,
            sealed_at TEXT
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS nodes (
            evidence_id TEXT PRIMARY KEY,
            episode_id TEXT NOT NULL,
            kind TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            FOREIGN KEY (episode_id) REFERENCES episodes(episode_id)
        )
    """)
    
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_nodes_episode ON nodes(episode_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_nodes_kind ON nodes(kind)")
    
    conn.commit()
    conn.close()


def persist_episode(episode_id: str, db_path: str = "provenance.db") -> None:
    """
    Persist an episode to SQLite database.
    
    Args:
        episode_id: Episode to persist
        db_path: Database path
    """
    if episode_id not in _provenance_store:
        raise ValueError(f"Episode {episode_id} not found")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Insert episode
    seal_hash = _sealed_episodes.get(episode_id)
    sealed_at = datetime.utcnow().isoformat() if seal_hash else None
    
    cursor.execute(
        "INSERT OR REPLACE INTO episodes (episode_id, seal_hash, sealed_at) VALUES (?, ?, ?)",
        (episode_id, seal_hash, sealed_at)
    )
    
    # Insert nodes
    for node in _provenance_store[episode_id]:
        cursor.execute(
            """INSERT OR REPLACE INTO nodes 
               (evidence_id, episode_id, kind, payload_json, timestamp) 
               VALUES (?, ?, ?, ?, ?)""",
            (
                node["evidence_id"],
                node["episode_id"],
                node["kind"],
                json.dumps(node["payload"]),
                node["timestamp"]
            )
        )
    
    conn.commit()
    conn.close()


# ============================================================================
# Example Usage
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  PROVENANCE STORE - EXAMPLE USAGE")
    print("=" * 70)
    
    # Create episode
    episode_id = "ep_20251018_test"
    
    # Attach various artifacts
    node1 = attach_artifact(episode_id, "signal", {"psi": 0.15})
    print(f"\n✅ Attached signal: {node1}")
    
    node2 = attach_artifact(episode_id, "policy_proof", {
        "policy_id": "P1",
        "threshold": 0.2,
        "observed": 0.15,
        "passed": True
    })
    print(f"✅ Attached policy proof: {node2}")
    
    node3 = attach_artifact(episode_id, "explanation", {
        "summary": "Approved due to low risk",
        "top_features": ["income", "credit_score"]
    })
    print(f"✅ Attached explanation: {node3}")
    
    # Seal episode
    seal = seal_episode(episode_id)
    print(f"\n🔒 Episode sealed: {seal[:16]}...")
    
    # Verify seal
    is_valid = verify_seal(episode_id, seal)
    print(f"✅ Seal verification: {is_valid}")
    
    # Get stats
    stats = get_store_stats()
    print(f"\n📊 Store stats: {stats}")
    
    # Validate evidence nodes
    all_found, missing = validate_evidence_nodes([node1, node2, node3])
    print(f"✅ Evidence validation: all_found={all_found}, missing={missing}")
    
    print("\n" + "=" * 70)
    print("✅ PROVENANCE STORE READY")
    print("=" * 70)
