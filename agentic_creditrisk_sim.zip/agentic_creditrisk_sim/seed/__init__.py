"""Synthetic data generation with ground-truth tagging."""

from .synthetic import (
    generate_synthetic_dataset,
    inject_drift,
    inject_bias,
    compute_psi,
    validate_ground_truth
)

__all__ = [
    'generate_synthetic_dataset',
    'inject_drift',
    'inject_bias',
    'compute_psi',
    'validate_ground_truth'
]
