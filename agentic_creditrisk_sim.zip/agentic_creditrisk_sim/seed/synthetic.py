"""
Synthetic Data Generator with Ground-Truth Tagging
===================================================
Generates credit risk data with deterministic truth flags for validation:
- drift_truth: Batches with PSI shift > 0.2 (model drift)
- bias_truth: Samples where protected proxy impacts decision (fairness)

Used for:
- Policy precision metrics (P1/P2 confusion matrix)
- Ablation studies with known violations
- Paper metrics validation
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple, Optional
from pathlib import Path


# Feature distributions (approximate German Credit dataset)
FEATURE_RANGES = {
    "age": (19, 75),
    "credit_amount": (250, 18424),
    "duration": (4, 72),
    "installment_rate": (1, 4),
    "residence_since": (1, 4),
    "existing_credits": (1, 4),
    "num_dependents": (1, 2),
    "job": (0, 3),  # Encoded: 0=unskilled, 1=skilled, 2=highly_skilled, 3=management
}

# Protected attributes for bias injection
PROTECTED_ATTRIBUTES = ["age", "sex", "foreign_worker"]


def generate_baseline_sample(seed: Optional[int] = None) -> Dict[str, Any]:
    """
    Generate one baseline credit risk sample.
    
    Args:
        seed: Random seed for reproducibility
        
    Returns:
        Dict with feature values
    """
    if seed is not None:
        np.random.seed(seed)
    
    # Continuous features
    sample = {
        "age": np.random.randint(19, 76),
        "credit_amount": np.random.randint(250, 18425),
        "duration": np.random.randint(4, 73),
        "installment_rate": np.random.randint(1, 5),
        "residence_since": np.random.randint(1, 5),
        "existing_credits": np.random.randint(1, 5),
        "num_dependents": np.random.randint(1, 3),
        "job": np.random.randint(0, 4),
    }
    
    # Categorical features (simplified)
    sample["checking_status"] = np.random.choice(["<0", "0<=X<200", ">=200", "no_checking"])
    sample["credit_history"] = np.random.choice(["no_credits", "all_paid", "existing_paid", "delayed", "critical"])
    sample["purpose"] = np.random.choice(["new_car", "used_car", "furniture", "radio_tv", "education", "business"])
    sample["savings_status"] = np.random.choice(["<100", "100<=X<500", "500<=X<1000", ">=1000", "no_savings"])
    sample["employment"] = np.random.choice(["unemployed", "<1", "1<=X<4", "4<=X<7", ">=7"])
    sample["personal_status"] = np.random.choice(["male_single", "female_single", "male_married", "female_married"])
    sample["other_parties"] = np.random.choice(["none", "co_applicant", "guarantor"])
    sample["property_magnitude"] = np.random.choice(["real_estate", "savings_insurance", "car", "no_property"])
    sample["other_payment_plans"] = np.random.choice(["bank", "stores", "none"])
    sample["housing"] = np.random.choice(["rent", "own", "for_free"])
    sample["telephone"] = np.random.choice(["none", "yes"])
    sample["foreign_worker"] = np.random.choice(["yes", "no"])
    
    # Derived features for bias detection
    sample["sex"] = "male" if "male" in sample["personal_status"] else "female"
    
    # True label (0=good, 1=bad credit)
    # Simplified risk model: higher credit amount, longer duration, younger age = higher risk
    risk_score = (
        (sample["credit_amount"] / 10000) * 0.3 +
        (sample["duration"] / 72) * 0.3 +
        (1 - (sample["age"] - 19) / (75 - 19)) * 0.2 +
        (sample["installment_rate"] / 4) * 0.1 +
        (sample["job"] == 0) * 0.1  # Unskilled = higher risk
    )
    
    sample["class"] = 1 if risk_score > 0.5 else 0  # 1=bad, 0=good
    
    return sample


def inject_drift(
    samples: pd.DataFrame,
    psi_shift: float = 0.25,
    affected_features: list = None
) -> pd.DataFrame:
    """
    Inject distributional drift into samples.
    
    Args:
        samples: Original samples
        psi_shift: Target PSI value (0.2 = significant drift)
        affected_features: Features to shift (default: age, credit_amount)
        
    Returns:
        Drifted samples with drift_truth=True
    """
    if affected_features is None:
        affected_features = ["age", "credit_amount"]
    
    drifted = samples.copy()
    
    for feature in affected_features:
        if feature in drifted.columns:
            # Shift distribution: add systematic bias
            if feature == "age":
                # Age shift: make population younger (higher risk)
                drifted[feature] = drifted[feature] * 0.85 + 5
            elif feature == "credit_amount":
                # Credit amount shift: increase amounts
                drifted[feature] = drifted[feature] * 1.3
            elif feature == "duration":
                # Duration shift: longer loans
                drifted[feature] = drifted[feature] * 1.2
    
    drifted["drift_truth"] = True
    return drifted


def inject_bias(
    samples: pd.DataFrame,
    protected_attr: str = "age",
    bias_magnitude: float = 0.15
) -> pd.DataFrame:
    """
    Inject bias where protected attribute impacts credit score.
    
    Args:
        samples: Original samples
        protected_attr: Protected attribute to bias (age, sex, foreign_worker)
        bias_magnitude: Impact on risk score (0.15 = 15% impact)
        
    Returns:
        Biased samples with bias_truth=True
    """
    biased = samples.copy()
    
    # Identify disadvantaged group
    if protected_attr == "age":
        # Young people (<30) systematically penalized
        disadvantaged_mask = biased["age"] < 30
    elif protected_attr == "sex":
        # Female systematically penalized
        disadvantaged_mask = biased["sex"] == "female"
    elif protected_attr == "foreign_worker":
        # Foreign workers penalized
        disadvantaged_mask = biased["foreign_worker"] == "yes"
    else:
        disadvantaged_mask = pd.Series([False] * len(biased))
    
    # Modify credit amount or duration to simulate bias effect
    biased.loc[disadvantaged_mask, "credit_amount"] = (
        biased.loc[disadvantaged_mask, "credit_amount"] * (1 + bias_magnitude)
    )
    biased.loc[disadvantaged_mask, "duration"] = (
        biased.loc[disadvantaged_mask, "duration"] * (1 + bias_magnitude * 0.5)
    )
    
    biased["bias_truth"] = disadvantaged_mask
    return biased


def generate_synthetic_dataset(
    n_samples: int = 1000,
    drift_ratio: float = 0.2,
    bias_ratio: float = 0.15,
    seed: int = 42
) -> pd.DataFrame:
    """
    Generate complete synthetic dataset with ground-truth flags.
    
    Args:
        n_samples: Total number of samples
        drift_ratio: Fraction of samples with drift (0.2 = 20%)
        bias_ratio: Fraction of samples with bias (0.15 = 15%)
        seed: Random seed
        
    Returns:
        DataFrame with features, labels, drift_truth, bias_truth
    """
    np.random.seed(seed)
    
    # Generate baseline samples
    samples = []
    for i in range(n_samples):
        sample = generate_baseline_sample(seed=seed + i)
        sample["sample_id"] = f"sample_{i:05d}"
        samples.append(sample)
    
    df = pd.DataFrame(samples)
    
    # Initialize truth flags
    df["drift_truth"] = False
    df["bias_truth"] = False
    
    # Inject drift into subset
    n_drift = int(n_samples * drift_ratio)
    if n_drift > 0:
        drift_indices = np.random.choice(len(df), size=n_drift, replace=False)
        df.loc[drift_indices, "drift_truth"] = True
        
        # Apply drift transformation
        drifted_samples = inject_drift(
            df.loc[drift_indices],
            psi_shift=0.25,
            affected_features=["age", "credit_amount", "duration"]
        )
        df.loc[drift_indices] = drifted_samples
    
    # Inject bias into different subset
    n_bias = int(n_samples * bias_ratio)
    if n_bias > 0:
        # Select from remaining non-drift samples
        non_drift_indices = df[~df["drift_truth"]].index
        bias_indices = np.random.choice(non_drift_indices, size=min(n_bias, len(non_drift_indices)), replace=False)
        
        biased_samples = inject_bias(
            df.loc[bias_indices],
            protected_attr="age",
            bias_magnitude=0.15
        )
        df.loc[bias_indices] = biased_samples
    
    return df


def compute_psi(
    reference: pd.Series,
    current: pd.Series,
    bins: int = 10
) -> float:
    """
    Compute Population Stability Index (PSI) between two distributions.
    
    Args:
        reference: Reference distribution
        current: Current distribution
        bins: Number of bins for discretization
        
    Returns:
        PSI value (>0.2 = significant drift)
    """
    # Create bins based on reference distribution
    percentiles = np.linspace(0, 100, bins + 1)
    bin_edges = np.percentile(reference, percentiles)
    
    # Compute proportions
    ref_counts, _ = np.histogram(reference, bins=bin_edges)
    curr_counts, _ = np.histogram(current, bins=bin_edges)
    
    ref_props = ref_counts / len(reference)
    curr_props = curr_counts / len(current)
    
    # Add small epsilon to avoid log(0)
    epsilon = 1e-10
    ref_props = np.maximum(ref_props, epsilon)
    curr_props = np.maximum(curr_props, epsilon)
    
    # PSI formula: sum((curr - ref) * log(curr / ref))
    psi = np.sum((curr_props - ref_props) * np.log(curr_props / ref_props))
    
    return psi


def validate_ground_truth(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Validate that ground-truth flags align with actual drift/bias.
    
    Args:
        df: Dataset with truth flags
        
    Returns:
        Validation metrics
    """
    # Split into drift vs non-drift
    drift_samples = df[df["drift_truth"]]
    non_drift_samples = df[~df["drift_truth"]]
    
    # Compute PSI for age (should be >0.2 for drift samples)
    if len(drift_samples) > 0 and len(non_drift_samples) > 0:
        psi_age = compute_psi(
            non_drift_samples["age"],
            drift_samples["age"]
        )
    else:
        psi_age = 0.0
    
    # Check bias impact
    bias_samples = df[df["bias_truth"]]
    avg_credit_bias = bias_samples["credit_amount"].mean() if len(bias_samples) > 0 else 0
    avg_credit_nobias = df[~df["bias_truth"]]["credit_amount"].mean() if len(df[~df["bias_truth"]]) > 0 else 0
    bias_impact_pct = ((avg_credit_bias - avg_credit_nobias) / avg_credit_nobias * 100) if avg_credit_nobias > 0 else 0
    
    return {
        "n_samples": len(df),
        "n_drift": df["drift_truth"].sum(),
        "n_bias": df["bias_truth"].sum(),
        "drift_ratio": df["drift_truth"].mean(),
        "bias_ratio": df["bias_truth"].mean(),
        "psi_age_drift_vs_baseline": psi_age,
        "bias_impact_pct": bias_impact_pct
    }


# ============================================================================
# CLI Interface
# ============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Generate synthetic credit risk data with ground truth")
    parser.add_argument("--n", type=int, default=1000, help="Number of samples")
    parser.add_argument("--drift-ratio", type=float, default=0.2, help="Fraction with drift")
    parser.add_argument("--bias-ratio", type=float, default=0.15, help="Fraction with bias")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--output", type=str, default="data/synthetic_credit.csv", help="Output path")
    args = parser.parse_args()
    
    print("=" * 70)
    print("  SYNTHETIC DATA GENERATOR WITH GROUND-TRUTH TAGGING")
    print("=" * 70)
    
    # Generate dataset
    print(f"\n🎲 Generating {args.n} samples (seed={args.seed})...")
    df = generate_synthetic_dataset(
        n_samples=args.n,
        drift_ratio=args.drift_ratio,
        bias_ratio=args.bias_ratio,
        seed=args.seed
    )
    
    # Validate ground truth
    print("\n📊 Validating ground-truth flags...")
    metrics = validate_ground_truth(df)
    
    print(f"\n✅ Dataset generated:")
    print(f"   Total samples: {metrics['n_samples']}")
    print(f"   Drift samples: {metrics['n_drift']} ({metrics['drift_ratio']:.1%})")
    print(f"   Bias samples: {metrics['n_bias']} ({metrics['bias_ratio']:.1%})")
    print(f"   PSI (age drift vs baseline): {metrics['psi_age_drift_vs_baseline']:.3f}")
    print(f"   Bias impact on credit amount: {metrics['bias_impact_pct']:.1f}%")
    
    # Save to CSV
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    
    print(f"\n💾 Saved to: {output_path}")
    print(f"   Shape: {df.shape}")
    print(f"   Columns: {list(df.columns)}")
    
    print("\n" + "=" * 70)
    print("✅ SYNTHETIC DATA READY")
    print("=" * 70)
