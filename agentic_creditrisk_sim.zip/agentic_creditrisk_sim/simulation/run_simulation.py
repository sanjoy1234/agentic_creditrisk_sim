"""
Simulation runner for batch credit risk assessment.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from tqdm import tqdm
import sys
import argparse
import time
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.predict import CreditRiskPredictor
from agents.compliance import ComplianceAgent
from agents.provenance import ProvenanceAgent
from agents.finops import FinOpsAgent


def load_test_data() -> pd.DataFrame:
    """Load test dataset."""
    data_path = Path(__file__).parent.parent / "data" / "german_credit.csv"
    
    if not data_path.exists():
        print("❌ Dataset not found. Please run 'make train' first.")
        sys.exit(1)
    
    data = pd.read_csv(data_path)
    
    # Take first 100 samples for simulation
    return data.head(100)


def run_simulation(seed=42, use_provenance=True, use_compliance=True, use_finops=True, output_path=None):
    """
    Run batch simulation with optional agent ablation.
    
    Args:
        seed: Random seed for reproducibility
        use_provenance: Enable provenance agent
        use_compliance: Enable compliance agent
        use_finops: Enable FinOps agent
        output_path: Path to save results CSV
    """
    np.random.seed(seed)
    
    print("=" * 70)
    print("  AGENTIC CREDIT RISK SIMULATION")
    print("=" * 70)
    print(f"  Seed: {seed}")
    print(f"  Provenance: {'✅' if use_provenance else '❌'}")
    print(f"  Compliance: {'✅' if use_compliance else '❌'}")
    print(f"  FinOps: {'✅' if use_finops else '❌'}")
    print("=" * 70)
    
    # Load test data
    print("\n📥 Loading test data...")
    data = load_test_data()
    X = data.drop('target', axis=1)
    y_true = data['target']
    
    print(f"✅ Loaded {len(X)} samples")
    
    # Initialize components
    print("\n🔧 Initializing agents...")
    
    try:
        predictor = CreditRiskPredictor()
        print("  ✅ Predictor")
    except Exception as e:
        print(f"  ❌ Predictor: {e}")
        print("\n💡 Please run 'make train' first to train the model.")
        sys.exit(1)
    
    compliance_agent = ComplianceAgent() if use_compliance else None
    print(f"  {'✅' if use_compliance else '⏭️ '} Compliance Agent")
    
    provenance_agent = ProvenanceAgent() if use_provenance else None
    print(f"  {'✅' if use_provenance else '⏭️ '} Provenance Agent")
    
    finops_agent = FinOpsAgent() if use_finops else None
    print(f"  {'✅' if use_finops else '⏭️ '} FinOps Agent")
    
    # Run simulation
    print("\n🎮 Running simulation...")
    
    results = []
    policy_triggers = {'P1': 0, 'P2': 0, 'P3': 0}
    baseline_latencies = []
    aacp_latencies = []
    
    for idx in tqdm(range(len(X)), desc="Processing"):
        sample = X.iloc[idx:idx+1]
        true_label = y_true.iloc[idx]
        
        # Baseline latency (model only)
        start_baseline = time.time()
        pred = predictor.predict(sample)[0]
        pred_proba = predictor.predict_proba(sample)[0]
        baseline_latency = (time.time() - start_baseline) * 1000  # ms
        baseline_latencies.append(baseline_latency)
        
        # AACP latency (full pipeline)
        start_aacp = time.time()
        
        # Simulate PSI with some variation
        psi_score = 0.15 + np.random.normal(0, 0.05)
        psi_score = max(0, min(0.3, psi_score))
        
        context = {
            'psi_score': psi_score,
            'decision': 'reject' if pred == 0 else 'approve',
            'explanation': {
                'top_features': ['duration', 'credit_amount', 'age'],
                'counterfactual': 'Reduce loan amount by 20%' if pred == 0 else None
            }
        }
        
        # Policy checks
        policy_results = []
        if compliance_agent:
            policy_results = compliance_agent.evaluate_all(context)
            
            # Count triggers
            for result in policy_results:
                if result['outcome'] != 'pass':
                    policy_id = result['policy_id']
                    if policy_id in policy_triggers:
                        policy_triggers[policy_id] += 1
        
        # Track costs
        cost_info = {'total_cost': 0.001}  # Default baseline
        if finops_agent:
            cost_info = finops_agent.track_inference({
                'shap_computed': True,
                'counterfactual_generated': context['decision'] == 'reject'
            })
        
        # Log to provenance
        has_explanation = False
        if provenance_agent:
            provenance_agent.log_decision({
                'customer_id': f'cust_{idx}',
                'decision': context['decision'],
                'model_version': 'v1.0.0',
                'features': sample.to_dict('records')[0],
                'prediction_proba': float(pred_proba[1]),
                'policy_results': policy_results,
                'explanation': context['explanation']
            })
            has_explanation = context['explanation']['counterfactual'] is not None
        
        aacp_latency = (time.time() - start_aacp) * 1000  # ms
        aacp_latencies.append(aacp_latency)
        
        results.append({
            'sample_id': idx,
            'true_label': true_label,
            'predicted': pred,
            'probability': pred_proba[1],
            'decision': context['decision'],
            'psi_score': psi_score,
            'policies_passed': all(r['outcome'] == 'pass' for r in policy_results) if policy_results else True,
            'p1_triggered': any(r['policy_id'] == 'P1' and r['outcome'] != 'pass' for r in policy_results) if policy_results else False,
            'p2_triggered': any(r['policy_id'] == 'P2' and r['outcome'] != 'pass' for r in policy_results) if policy_results else False,
            'p3_triggered': any(r['policy_id'] == 'P3' and r['outcome'] != 'pass' for r in policy_results) if policy_results else False,
            'has_explanation': has_explanation,
            'baseline_latency_ms': baseline_latency,
            'aacp_latency_ms': aacp_latency,
            'cost': cost_info['total_cost']
        })
    
    # Summary
    results_df = pd.DataFrame(results)
    
    print("\n" + "=" * 70)
    print("  SIMULATION RESULTS")
    print("=" * 70)
    
    print(f"\n📊 Summary:")
    print(f"  • Total samples: {len(results_df)}")
    print(f"  • Approvals: {(results_df['decision'] == 'approve').sum()}")
    print(f"  • Rejections: {(results_df['decision'] == 'reject').sum()}")
    print(f"  • Policies passed: {results_df['policies_passed'].sum()}")
    
    if finops_agent:
        print(f"  • Total cost: ${finops_agent.total_cost:.4f}")
        print(f"  • Avg cost per inference: ${finops_agent.total_cost / len(results_df):.6f}")
    
    # Accuracy
    accuracy = (results_df['predicted'] == results_df['true_label']).mean()
    print(f"\n🎯 Model Accuracy: {accuracy:.2%}")
    
    # Latency
    print(f"\n⏱️  Latency:")
    print(f"  • Baseline (model only): {np.mean(baseline_latencies):.2f} ms (±{np.std(baseline_latencies):.2f})")
    print(f"  • AACP (full pipeline): {np.mean(aacp_latencies):.2f} ms (±{np.std(aacp_latencies):.2f})")
    
    # Policy triggers
    if compliance_agent:
        print(f"\n⚖️  Policy Triggers:")
        for policy_id, count in policy_triggers.items():
            print(f"  • {policy_id}: {count} ({count/len(results_df)*100:.1f}%)")
    
    # Evidence coverage
    if provenance_agent:
        evidence_coverage = results_df['has_explanation'].sum() / len(results_df) * 100
        print(f"\n📝 Evidence Coverage: {evidence_coverage:.1f}%")
    
    # Save results
    if output_path is None:
        output_path = Path(__file__).parent.parent / "results" / "simulation_results.csv"
    
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    results_df.to_csv(output_path, index=False)
    print(f"\n💾 Results saved to: {output_path}")
    
    print("\n✅ Simulation complete!")
    
    return results_df, {
        'accuracy': accuracy,
        'total_samples': len(results_df),
        'approvals': (results_df['decision'] == 'approve').sum(),
        'rejections': (results_df['decision'] == 'reject').sum(),
        'policies_passed': results_df['policies_passed'].sum(),
        'total_cost': finops_agent.total_cost if finops_agent else 0,
        'avg_baseline_latency': np.mean(baseline_latencies),
        'avg_aacp_latency': np.mean(aacp_latencies),
        'policy_triggers': policy_triggers,
        'evidence_coverage': results_df['has_explanation'].sum() / len(results_df) * 100 if provenance_agent else 0
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Run AACP simulation')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    parser.add_argument('--no-provenance', action='store_true', help='Disable provenance agent')
    parser.add_argument('--no-compliance', action='store_true', help='Disable compliance agent')
    parser.add_argument('--no-finops', action='store_true', help='Disable FinOps agent')
    parser.add_argument('--output', type=str, help='Output CSV path')
    
    args = parser.parse_args()
    
    run_simulation(
        seed=args.seed,
        use_provenance=not args.no_provenance,
        use_compliance=not args.no_compliance,
        use_finops=not args.no_finops,
        output_path=args.output
    )
