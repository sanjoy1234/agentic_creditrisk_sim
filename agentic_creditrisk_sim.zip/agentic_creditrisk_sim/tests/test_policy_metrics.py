"""
Policy Precision and P3 Coverage Tests
=======================================
Tests for:
1. P1 precision metrics (drift detection) - should be >0.9 on synthetic data
2. P3 coverage (explanation for all rejects) - should be 100%
"""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from simulation.enhanced_run_simulation import (
    compute_policy_precision_metrics,
    compute_p3_coverage,
    run_enhanced_simulation
)
from seed.synthetic import generate_synthetic_dataset


def test_p1_precision_metrics():
    """
    Test P1 precision/recall with injected drift.
    
    Expected:
    - Precision > 0.9 (few false positives)
    - Recall > 0.9 (catches most drift)
    - F1 > 0.9
    """
    print("\n" + "=" * 70)
    print("TEST: P1 Precision Metrics")
    print("=" * 70)
    
    # Generate data with known drift
    data = generate_synthetic_dataset(
        n_samples=200,
        drift_ratio=0.3,  # 30% drift for clear signal
        bias_ratio=0.1,
        seed=42
    )
    
    # Simulate perfect P1 predictions (should detect drift correctly)
    # P1 triggers when PSI > 0.2, which should correlate with drift_truth
    np.random.seed(42)
    
    # Simulate P1 predictions with high accuracy
    # True positives: 90% of drift samples detected
    # False positives: 5% of non-drift flagged as drift
    drift_samples_mask = data['drift_truth']
    
    p1_pred = np.zeros(len(data), dtype=bool)
    
    # True positives: Detect 90% of drift
    drift_indices = np.where(drift_samples_mask)[0]
    detected_drift = np.random.choice(drift_indices, size=int(len(drift_indices) * 0.9), replace=False)
    p1_pred[detected_drift] = True
    
    # False positives: 5% of non-drift
    non_drift_indices = np.where(~drift_samples_mask)[0]
    false_positives = np.random.choice(non_drift_indices, size=int(len(non_drift_indices) * 0.05), replace=False)
    p1_pred[false_positives] = True
    
    # Add to dataframe
    test_df = data.copy()
    test_df['p1_pred'] = p1_pred
    
    # Compute metrics
    metrics = compute_policy_precision_metrics(test_df)
    
    assert 'P1' in metrics, "P1 metrics should be computed"
    
    p1_metrics = metrics['P1']
    print(f"\nP1 Metrics:")
    print(f"  Precision: {p1_metrics['precision']:.3f}")
    print(f"  Recall: {p1_metrics['recall']:.3f}")
    print(f"  F1: {p1_metrics['f1']:.3f}")
    print(f"  Accuracy: {p1_metrics['accuracy']:.3f}")
    print(f"  TP: {p1_metrics['tp']}, FP: {p1_metrics['fp']}, FN: {p1_metrics['fn']}, TN: {p1_metrics['tn']}")
    
    # Assertions
    assert p1_metrics['precision'] > 0.85, f"P1 precision should be >0.85, got {p1_metrics['precision']:.3f}"
    assert p1_metrics['recall'] > 0.85, f"P1 recall should be >0.85, got {p1_metrics['recall']:.3f}"
    assert p1_metrics['f1'] > 0.85, f"P1 F1 should be >0.85, got {p1_metrics['f1']:.3f}"
    
    print("\n✅ P1 precision metrics test PASSED")
    print(f"   Precision={p1_metrics['precision']:.3f}, Recall={p1_metrics['recall']:.3f}, F1={p1_metrics['f1']:.3f}")


def test_p3_coverage():
    """
    Test P3 coverage: all rejects should have explanations.
    
    Expected:
    - Coverage = 100% (target)
    - All rejects have explanation_ref
    - All rejects have counterfactuals
    """
    print("\n" + "=" * 70)
    print("TEST: P3 Coverage")
    print("=" * 70)
    
    # Create test dataset with rejects
    np.random.seed(42)
    n_samples = 100
    n_rejects = 30
    
    # Generate sample IDs
    sample_ids = [f"sample_{i:03d}" for i in range(n_samples)]
    
    # Create decisions
    decisions = ['approve'] * (n_samples - n_rejects) + ['reject'] * n_rejects
    np.random.shuffle(decisions)
    
    # Create explanation_ref for all rejects (P3 enforcement)
    explanation_refs = [
        f"exp_{sample_id}" if decision == 'reject' else None
        for sample_id, decision in zip(sample_ids, decisions)
    ]
    
    # Create counterfactuals for all rejects
    counterfactuals = [
        f"Reduce loan amount by 20%" if decision == 'reject' else None
        for decision in decisions
    ]
    
    test_df = pd.DataFrame({
        'sample_id': sample_ids,
        'decision': decisions,
        'explanation_ref': explanation_refs,
        'counterfactual': counterfactuals
    })
    
    # Compute P3 coverage
    p3_metrics = compute_p3_coverage(test_df)
    
    print(f"\nP3 Coverage:")
    print(f"  Coverage: {p3_metrics['coverage_pct']:.1f}%")
    print(f"  Total rejects: {p3_metrics['total_rejects']}")
    print(f"  Rejects with explanation: {p3_metrics['rejects_with_explanation']}")
    
    # Assertions
    assert p3_metrics['coverage_pct'] == 100.0, \
        f"P3 coverage should be 100%, got {p3_metrics['coverage_pct']:.1f}%"
    assert p3_metrics['total_rejects'] == n_rejects, \
        f"Should have {n_rejects} rejects, got {p3_metrics['total_rejects']}"
    assert p3_metrics['rejects_with_explanation'] == n_rejects, \
        f"All {n_rejects} rejects should have explanations, got {p3_metrics['rejects_with_explanation']}"
    
    # Verify all rejects have counterfactuals
    rejects_df = test_df[test_df['decision'] == 'reject']
    assert rejects_df['counterfactual'].notna().all(), \
        "All rejects should have counterfactuals"
    
    print("\n✅ P3 coverage test PASSED")
    print(f"   Coverage={p3_metrics['coverage_pct']:.1f}%, All rejects explained")


def test_p3_coverage_violation():
    """
    Test P3 coverage violation detection (some rejects missing explanations).
    
    Expected:
    - Coverage < 100% when explanations missing
    - Correctly counts rejects without explanations
    """
    print("\n" + "=" * 70)
    print("TEST: P3 Coverage Violation Detection")
    print("=" * 70)
    
    np.random.seed(42)
    n_samples = 100
    n_rejects = 40
    n_missing_explanations = 10  # 10 rejects missing explanations
    
    sample_ids = [f"sample_{i:03d}" for i in range(n_samples)]
    decisions = ['approve'] * (n_samples - n_rejects) + ['reject'] * n_rejects
    np.random.shuffle(decisions)
    
    # Create explanation_ref, but leave some rejects without explanations
    explanation_refs = []
    reject_count = 0
    for sample_id, decision in zip(sample_ids, decisions):
        if decision == 'reject':
            reject_count += 1
            # Skip explanations for first 10 rejects
            if reject_count <= n_missing_explanations:
                explanation_refs.append(None)  # VIOLATION
            else:
                explanation_refs.append(f"exp_{sample_id}")
        else:
            explanation_refs.append(None)
    
    test_df = pd.DataFrame({
        'sample_id': sample_ids,
        'decision': decisions,
        'explanation_ref': explanation_refs
    })
    
    # Compute P3 coverage
    p3_metrics = compute_p3_coverage(test_df)
    
    expected_coverage = ((n_rejects - n_missing_explanations) / n_rejects) * 100
    
    print(f"\nP3 Coverage (with violations):")
    print(f"  Coverage: {p3_metrics['coverage_pct']:.1f}%")
    print(f"  Total rejects: {p3_metrics['total_rejects']}")
    print(f"  Rejects with explanation: {p3_metrics['rejects_with_explanation']}")
    print(f"  Missing explanations: {n_missing_explanations}")
    
    # Assertions
    assert p3_metrics['coverage_pct'] == expected_coverage, \
        f"Coverage should be {expected_coverage:.1f}%, got {p3_metrics['coverage_pct']:.1f}%"
    assert p3_metrics['total_rejects'] == n_rejects, \
        f"Should have {n_rejects} rejects"
    assert p3_metrics['rejects_with_explanation'] == (n_rejects - n_missing_explanations), \
        f"Should have {n_rejects - n_missing_explanations} rejects with explanations"
    
    # Verify coverage < 100%
    assert p3_metrics['coverage_pct'] < 100.0, \
        "Coverage should be <100% when explanations are missing"
    
    print("\n✅ P3 violation detection test PASSED")
    print(f"   Detected {n_missing_explanations} missing explanations correctly")


def test_end_to_end_simulation():
    """
    End-to-end test with small simulation run.
    
    Verifies:
    - P1 precision metrics computed
    - P3 coverage = 100%
    - Paper metrics exported
    """
    print("\n" + "=" * 70)
    print("TEST: End-to-End Simulation")
    print("=" * 70)
    
    # Run small simulation
    results_df, paper_metrics = run_enhanced_simulation(
        n_samples=50,
        seed=42,
        use_provenance=True,
        use_compliance=True,
        use_finops=True,
        force_reject_ratio=0.2,  # Force 20% rejects
        output_path="/tmp/test_simulation_results.csv"
    )
    
    print("\n📊 Simulation completed")
    print(f"   Samples: {len(results_df)}")
    print(f"   Rejects: {(results_df['decision'] == 'reject').sum()}")
    
    # Verify required columns exist
    required_columns = [
        'sample_id', 'decision', 'drift_truth', 'bias_truth',
        'p1_pred', 'p2_pred', 'p3_triggered', 'explanation_ref',
        'counterfactual', 'latency_seconds', 'cost'
    ]
    for col in required_columns:
        assert col in results_df.columns, f"Column '{col}' missing from results"
    
    # Verify paper metrics
    assert 'policy_metrics' in paper_metrics, "Paper metrics should include policy_metrics"
    assert 'p3_coverage' in paper_metrics, "Paper metrics should include p3_coverage"
    assert 'governance_completeness' in paper_metrics, "Paper metrics should include governance_completeness"
    
    # Verify P3 coverage
    p3_coverage = paper_metrics['p3_coverage']
    print(f"\n✅ P3 Coverage: {p3_coverage['coverage_pct']:.1f}%")
    
    # Should be 100% with force_reject and explanation generation
    assert p3_coverage['coverage_pct'] == 100.0, \
        f"P3 coverage should be 100%, got {p3_coverage['coverage_pct']:.1f}%"
    
    # Verify policy metrics exist
    if 'P1' in paper_metrics['policy_metrics']:
        p1_metrics = paper_metrics['policy_metrics']['P1']
        print(f"✅ P1 Metrics: Precision={p1_metrics['precision']:.3f}, Recall={p1_metrics['recall']:.3f}")
    
    # Verify governance completeness
    governance = paper_metrics['governance_completeness']
    print(f"✅ Governance Completeness: {governance:.2%}")
    assert governance > 0.5, f"Governance completeness should be >50%, got {governance:.2%}"
    
    print("\n✅ End-to-end simulation test PASSED")


# ============================================================================
# Run All Tests
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  RUNNING POLICY PRECISION & P3 COVERAGE TESTS")
    print("=" * 70)
    
    tests = [
        ("P1 Precision Metrics", test_p1_precision_metrics),
        ("P3 Coverage (100%)", test_p3_coverage),
        ("P3 Violation Detection", test_p3_coverage_violation),
        ("End-to-End Simulation", test_end_to_end_simulation)
    ]
    
    passed = 0
    failed = 0
    
    for name, test_func in tests:
        try:
            test_func()
            passed += 1
        except AssertionError as e:
            failed += 1
            print(f"\n❌ FAILED: {name}")
            print(f"   Error: {str(e)}")
        except Exception as e:
            failed += 1
            print(f"\n❌ ERROR: {name}")
            print(f"   Exception: {str(e)}")
            import traceback
            traceback.print_exc()
    
    print(f"\n{'=' * 70}")
    print(f"TEST SUMMARY")
    print('=' * 70)
    print(f"✅ Passed: {passed}/{len(tests)}")
    if failed > 0:
        print(f"❌ Failed: {failed}/{len(tests)}")
    print('=' * 70)
