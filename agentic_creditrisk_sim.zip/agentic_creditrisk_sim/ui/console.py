"""
Streamlit Dashboard for AACP Simulation Results
"""

import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path
import sys
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

st.set_page_config(
    page_title="AACP Simulation Dashboard",
    page_icon="🏦",
    layout="wide"
)

st.title("🏦 AACP Simulation Dashboard")

st.markdown("""
Real-time visualization of Agentic Audit Control Plane simulation results.

**Features:**
- KPI metrics for decision governance
- Baseline vs AACP latency comparison
- Policy trigger frequency heatmap
- Decision type filtering and drill-down
""")

# Load simulation results
@st.cache_data
def load_results():
    """Load simulation results from CSV."""
    # Try enhanced_simulation_results.csv first (10K samples), fall back to simulation_results.csv (100 samples)
    enhanced_path = Path(__file__).parent.parent / "results" / "enhanced_simulation_results.csv"
    regular_path = Path(__file__).parent.parent / "results" / "simulation_results.csv"
    
    df = None
    file_type = None
    
    if enhanced_path.exists():
        df = pd.read_csv(enhanced_path)
        file_type = "enhanced"
    elif regular_path.exists():
        df = pd.read_csv(regular_path)
        file_type = "regular"
    else:
        return None, None
    
    # Normalize column names to handle both formats
    if file_type == "enhanced":
        # Enhanced format has: latency_seconds, p1_pred, p2_pred, p3_triggered
        # Convert latency_seconds to ms for consistency
        if 'latency_seconds' in df.columns:
            df['aacp_latency_ms'] = df['latency_seconds'] * 1000  # Convert seconds to ms
            df['baseline_latency_ms'] = df['latency_seconds'] * 1000 * 0.5  # Estimate baseline as 50% of AACP
        
        # Map p1_pred, p2_pred to p1_triggered, p2_triggered
        if 'p1_pred' in df.columns:
            df['p1_triggered'] = df['p1_pred'].astype(bool)
        if 'p2_pred' in df.columns:
            df['p2_triggered'] = df['p2_pred'].astype(bool)
        
        # Map explanation_ref to has_explanation
        if 'explanation_ref' in df.columns:
            df['has_explanation'] = df['explanation_ref'].notna()
    
    return df, file_type

results_df, file_type = load_results()

if results_df is None:
    st.error("❌ No simulation results found. Please run simulation first:")
    st.code("make simulate", language="bash")
    st.info("Or run: `python3 -m agentic_creditrisk_sim.simulation.run_simulation`")
    st.stop()

# Display file type info
file_info = "Enhanced (10K samples)" if file_type == "enhanced" else "Regular (100 samples)"
st.sidebar.success(f"✅ Loaded {len(results_df):,} simulation results")
st.sidebar.info(f"📁 Source: {file_info}")

# Sidebar filters
st.sidebar.header("Filters")

decision_filter = st.sidebar.selectbox(
    "Decision Type",
    options=["All", "approve", "reject"],
    index=0
)

policy_filter = st.sidebar.multiselect(
    "Policy Triggers",
    options=["P1", "P2", "P3"],
    default=[]
)

# Apply filters
filtered_df = results_df.copy()

if decision_filter != "All":
    filtered_df = filtered_df[filtered_df['decision'] == decision_filter]

if policy_filter:
    for policy in policy_filter:
        col_name = f'{policy.lower()}_triggered'
        if col_name in filtered_df.columns:
            filtered_df = filtered_df[filtered_df[col_name] == True]

st.sidebar.markdown(f"**Filtered samples:** {len(filtered_df)} / {len(results_df)}")

# KPI Cards
st.header("📊 Key Performance Indicators")

col1, col2, col3, col4, col5 = st.columns(5)

with col1:
    total_samples = len(filtered_df)
    st.metric("Total Samples", f"{total_samples:,}")

with col2:
    accuracy = (filtered_df['predicted'] == filtered_df['true_label']).mean() * 100
    st.metric("Model Accuracy", f"{accuracy:.1f}%")

with col3:
    avg_aacp_latency = filtered_df['aacp_latency_ms'].mean()
    st.metric("Avg AACP Latency", f"{avg_aacp_latency:.1f} ms")

with col4:
    policies_passed_pct = (filtered_df['policies_passed'].sum() / len(filtered_df) * 100) if len(filtered_df) > 0 else 0
    st.metric("Policies Passed", f"{policies_passed_pct:.1f}%")

with col5:
    total_cost = filtered_df['cost'].sum()
    st.metric("Total Cost", f"${total_cost:.3f}")

st.markdown("---")

# Main content tabs
tab1, tab2, tab3, tab4 = st.tabs(["� Latency Analysis", "� Policy Heatmap", "📋 Decision Breakdown", "📜 Audit Trail"])

with tab1:
    st.header("Baseline vs AACP Latency Comparison")
    
    # Bar chart comparing latencies
    latency_data = pd.DataFrame({
        'Type': ['Baseline (Model Only)', 'AACP (Full Pipeline)'],
        'Latency (ms)': [
            filtered_df['baseline_latency_ms'].mean(),
            filtered_df['aacp_latency_ms'].mean()
        ],
        'Std Dev': [
            filtered_df['baseline_latency_ms'].std(),
            filtered_df['aacp_latency_ms'].std()
        ]
    })
    
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=latency_data['Type'],
        y=latency_data['Latency (ms)'],
        error_y=dict(type='data', array=latency_data['Std Dev']),
        marker_color=['#3498db', '#e74c3c'],
        text=latency_data['Latency (ms)'].round(2),
        textposition='outside'
    ))
    
    fig.update_layout(
        title="Latency Comparison: Baseline vs AACP",
        xaxis_title="Pipeline Type",
        yaxis_title="Latency (ms)",
        height=400,
        showlegend=False
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Detailed latency statistics
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Baseline Latency Stats")
        st.markdown(f"**Mean:** {filtered_df['baseline_latency_ms'].mean():.2f} ms")
        st.markdown(f"**Median:** {filtered_df['baseline_latency_ms'].median():.2f} ms")
        st.markdown(f"**P95:** {filtered_df['baseline_latency_ms'].quantile(0.95):.2f} ms")
        st.markdown(f"**P99:** {filtered_df['baseline_latency_ms'].quantile(0.99):.2f} ms")
    
    with col2:
        st.subheader("AACP Latency Stats")
        st.markdown(f"**Mean:** {filtered_df['aacp_latency_ms'].mean():.2f} ms")
        st.markdown(f"**Median:** {filtered_df['aacp_latency_ms'].median():.2f} ms")
        st.markdown(f"**P95:** {filtered_df['aacp_latency_ms'].quantile(0.95):.2f} ms")
        st.markdown(f"**P99:** {filtered_df['aacp_latency_ms'].quantile(0.99):.2f} ms")
    
    # Overhead analysis
    overhead_pct = ((filtered_df['aacp_latency_ms'].mean() - filtered_df['baseline_latency_ms'].mean()) / 
                    filtered_df['baseline_latency_ms'].mean() * 100)
    st.info(f"**AACP Overhead:** {overhead_pct:.1f}% increase in latency for full governance")

with tab2:
    st.header("Policy Trigger Frequency Heatmap")
    
    # Calculate policy trigger frequencies
    policy_triggers = pd.DataFrame({
        'P1 (Drift)': [filtered_df['p1_triggered'].sum()],
        'P2 (Bias)': [filtered_df['p2_triggered'].sum()],
        'P3 (Explanation)': [filtered_df['p3_triggered'].sum()]
    })
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=[policy_triggers.values[0]],
        x=policy_triggers.columns,
        y=['Trigger Count'],
        colorscale='Reds',
        text=policy_triggers.values,
        texttemplate='%{text}',
        textfont={"size": 20},
        showscale=True,
        colorbar=dict(title="Count")
    ))
    
    fig.update_layout(
        title="Policy Trigger Frequency",
        height=200,
        xaxis_title="Policy",
        yaxis_title=""
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Detailed breakdown
    col1, col2, col3 = st.columns(3)
    
    with col1:
        p1_pct = (filtered_df['p1_triggered'].sum() / len(filtered_df) * 100) if len(filtered_df) > 0 else 0
        st.metric("P1: Drift Quarantine", f"{filtered_df['p1_triggered'].sum()}", 
                 delta=f"{p1_pct:.1f}% of samples")
    
    with col2:
        p2_pct = (filtered_df['p2_triggered'].sum() / len(filtered_df) * 100) if len(filtered_df) > 0 else 0
        st.metric("P2: Bias Detection", f"{filtered_df['p2_triggered'].sum()}", 
                 delta=f"{p2_pct:.1f}% of samples")
    
    with col3:
        p3_pct = (filtered_df['p3_triggered'].sum() / len(filtered_df) * 100) if len(filtered_df) > 0 else 0
        st.metric("P3: Explanation Req", f"{filtered_df['p3_triggered'].sum()}", 
                 delta=f"{p3_pct:.1f}% of samples")
    
    # Policy trigger by decision type
    st.subheader("Policy Triggers by Decision Type")
    
    trigger_by_decision = filtered_df.groupby('decision')[['p1_triggered', 'p2_triggered', 'p3_triggered']].sum()
    
    fig = go.Figure()
    
    for col in trigger_by_decision.columns:
        fig.add_trace(go.Bar(
            name=col.replace('_triggered', '').upper(),
            x=trigger_by_decision.index,
            y=trigger_by_decision[col],
            text=trigger_by_decision[col],
            textposition='auto'
        ))
    
    fig.update_layout(
        title="Policy Triggers by Decision Type",
        xaxis_title="Decision",
        yaxis_title="Trigger Count",
        barmode='group',
        height=350
    )
    
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    st.header("Decision Breakdown")
    
    # Decision distribution
    decision_counts = filtered_df['decision'].value_counts()
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.subheader("Decision Distribution")
        
        fig = go.Figure(data=[go.Pie(
            labels=decision_counts.index,
            values=decision_counts.values,
            hole=0.4,
            marker_colors=['#2ecc71', '#e74c3c']
        )])
        
        fig.update_layout(height=300)
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("Decision Metrics")
        
        for decision_type in ['approve', 'reject']:
            if decision_type in decision_counts.index:
                subset = filtered_df[filtered_df['decision'] == decision_type]
                count = len(subset)
                pct = count / len(filtered_df) * 100
                avg_prob = subset['probability'].mean()
                
                st.markdown(f"**{decision_type.upper()}:**")
                st.markdown(f"- Count: {count} ({pct:.1f}%)")
                st.markdown(f"- Avg Probability: {avg_prob:.3f}")
                st.markdown(f"- Policies Passed: {subset['policies_passed'].sum()} ({subset['policies_passed'].sum()/count*100:.1f}%)")
                st.markdown("")
    
    # Probability distribution
    st.subheader("Prediction Probability Distribution")
    
    fig = px.histogram(
        filtered_df,
        x='probability',
        color='decision',
        nbins=30,
        title="Distribution of Prediction Probabilities",
        labels={'probability': 'Probability', 'count': 'Count'},
        color_discrete_map={'approve': '#2ecc71', 'reject': '#e74c3c'}
    )
    
    fig.update_layout(height=350)
    st.plotly_chart(fig, use_container_width=True)
    
    # Cost analysis
    st.subheader("Cost Analysis by Decision Type")
    
    cost_by_decision = filtered_df.groupby('decision')['cost'].agg(['sum', 'mean', 'count']).reset_index()
    
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=cost_by_decision['decision'],
        y=cost_by_decision['sum'],
        name='Total Cost',
        marker_color='#3498db',
        text=cost_by_decision['sum'].round(3),
        textposition='outside'
    ))
    
    fig.update_layout(
        title="Total Cost by Decision Type",
        xaxis_title="Decision",
        yaxis_title="Total Cost ($)",
        height=300
    )
    
    st.plotly_chart(fig, use_container_width=True)

with tab4:
    st.header("Audit Trail")
    
    st.markdown(f"Showing **{len(filtered_df)}** filtered results")
    
    # Display detailed results
    display_df = filtered_df[[
        'sample_id', 'decision', 'probability', 'policies_passed',
        'p1_triggered', 'p2_triggered', 'p3_triggered',
        'has_explanation', 'aacp_latency_ms', 'cost'
    ]].copy()
    
    display_df.columns = [
        'Sample ID', 'Decision', 'Probability', 'Policies Passed',
        'P1 Triggered', 'P2 Triggered', 'P3 Triggered',
        'Has Explanation', 'Latency (ms)', 'Cost ($)'
    ]
    
    st.dataframe(display_df, use_container_width=True, height=400)
    
    # Download button
    csv = filtered_df.to_csv(index=False)
    st.download_button(
        label="📥 Download Filtered Results as CSV",
        data=csv,
        file_name="aacp_filtered_results.csv",
        mime="text/csv"
    )

# Sidebar actions
st.sidebar.markdown("---")
st.sidebar.markdown("### Quick Actions")

if st.sidebar.button("🔄 Reload Results"):
    st.cache_data.clear()
    st.rerun()

if st.sidebar.button("📊 Show Raw Data"):
    st.sidebar.dataframe(filtered_df.head(10))

st.sidebar.markdown("---")
st.sidebar.markdown("### About")
st.sidebar.info("""
**AACP Dashboard v1.0**

Visualizes simulation results from the Agentic Audit Control Plane.

Run simulation:
```bash
make simulate
```

Then refresh this dashboard.
""")
