"""
Quick validation script for AACP implementation.

Tests:
1. Simulation generates valid results
2. Dashboard can load results
3. Ablation study runs (quick test with 2 seeds)
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from simulation.run_simulation import run_simulation


def test_simulation():
    """Test that simulation runs and generates valid results."""
    print("=" * 70)
    print("  TEST 1: SIMULATION")
    print("=" * 70)
    
    output_path = Path(__file__).parent / "results" / "test_simulation.csv"
    
    df, metrics = run_simulation(
        seed=42,
        use_provenance=True,
        use_compliance=True,
        use_finops=True,
        output_path=output_path
    )
    
    # Validate
    assert len(df) == 100, "Expected 100 samples"
    assert 'decision' in df.columns, "Missing 'decision' column"
    assert 'aacp_latency_ms' in df.columns, "Missing latency column"
    assert 'cost' in df.columns, "Missing cost column"
    assert metrics['accuracy'] > 0, "Invalid accuracy"
    
    print("\n✅ Simulation test PASSED")
    return df, metrics


def test_reproducibility():
    """Test that same seed produces same results."""
    print("\n" + "=" * 70)
    print("  TEST 2: REPRODUCIBILITY")
    print("=" * 70)
    
    # Run twice with same seed
    _, metrics1 = run_simulation(seed=42, use_provenance=True, use_compliance=True, use_finops=True)
    _, metrics2 = run_simulation(seed=42, use_provenance=True, use_compliance=True, use_finops=True)
    
    # Compare key metrics
    acc_diff = abs(metrics1['accuracy'] - metrics2['accuracy'])
    cost_diff = abs(metrics1['total_cost'] - metrics2['total_cost'])
    
    assert acc_diff < 0.01, f"Accuracy not reproducible: {acc_diff}"
    assert cost_diff < 0.001, f"Cost not reproducible: {cost_diff}"
    
    print(f"\n✅ Reproducibility test PASSED")
    print(f"   Accuracy difference: {acc_diff:.6f}")
    print(f"   Cost difference: ${cost_diff:.6f}")


def test_ablation():
    """Test ablation study with minimal seeds."""
    print("\n" + "=" * 70)
    print("  TEST 3: ABLATION STUDY (Quick)")
    print("=" * 70)
    
    from ablation import run_ablation_study
    
    # Run with just 2 seeds for quick test
    results, comparison_df = run_ablation_study(seeds=[42, 123])
    
    # Validate
    assert 'full' in results, "Missing full configuration"
    assert 'no_provenance' in results, "Missing no_provenance configuration"
    assert 'no_compliance' in results, "Missing no_compliance configuration"
    assert 'no_finops' in results, "Missing no_finops configuration"
    
    assert len(comparison_df) == 4, "Expected 4 configurations"
    
    print("\n✅ Ablation test PASSED")
    return results, comparison_df


def test_dashboard_load():
    """Test that dashboard can load results."""
    print("\n" + "=" * 70)
    print("  TEST 4: DASHBOARD DATA LOADING")
    print("=" * 70)
    
    results_path = Path(__file__).parent / "results" / "simulation_results.csv"
    
    assert results_path.exists(), "Results CSV not found"
    
    df = pd.read_csv(results_path)
    
    # Validate required columns
    required_cols = [
        'sample_id', 'decision', 'probability', 'policies_passed',
        'p1_triggered', 'p2_triggered', 'p3_triggered',
        'has_explanation', 'baseline_latency_ms', 'aacp_latency_ms', 'cost'
    ]
    
    for col in required_cols:
        assert col in df.columns, f"Missing required column: {col}"
    
    print(f"\n✅ Dashboard test PASSED")
    print(f"   Loaded {len(df)} samples")
    print(f"   All required columns present")
    
    # Print sample statistics
    print(f"\n📊 Sample Statistics:")
    print(f"   Accuracy: {(df['predicted'] == df['true_label']).mean()*100:.1f}%")
    print(f"   Avg AACP Latency: {df['aacp_latency_ms'].mean():.2f} ms")
    print(f"   Total Cost: ${df['cost'].sum():.4f}")
    print(f"   P1 Triggers: {df['p1_triggered'].sum()}")
    print(f"   P2 Triggers: {df['p2_triggered'].sum()}")
    print(f"   P3 Triggers: {df['p3_triggered'].sum()}")


def main():
    """Run all validation tests."""
    print("\n")
    print("╔" + "═" * 68 + "╗")
    print("║" + " " * 68 + "║")
    print("║" + "  AACP VALIDATION SUITE".center(68) + "║")
    print("║" + " " * 68 + "║")
    print("╚" + "═" * 68 + "╝")
    print("\n")
    
    try:
        # Test 1: Simulation
        df, metrics = test_simulation()
        
        # Test 2: Reproducibility
        test_reproducibility()
        
        # Test 3: Dashboard loading
        test_dashboard_load()
        
        # Test 4: Ablation (quick)
        print("\n" + "=" * 70)
        print("  TEST 4: ABLATION STUDY")
        print("=" * 70)
        print("\nSkipping full ablation (use: python -m agentic_creditrisk_sim.ablation)")
        print("Run 'make ablation' for complete study with all seeds")
        
        # Final summary
        print("\n\n" + "╔" + "═" * 68 + "╗")
        print("║" + " " * 68 + "║")
        print("║" + "  ✅ ALL VALIDATION TESTS PASSED".center(68) + "║")
        print("║" + " " * 68 + "║")
        print("╚" + "═" * 68 + "╝")
        
        print("\n📋 Next Steps:")
        print("   1. Run simulation: make simulate")
        print("   2. Launch dashboard: streamlit run agentic_creditrisk_sim/ui/console.py")
        print("   3. Run ablation study: make ablation")
        
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
