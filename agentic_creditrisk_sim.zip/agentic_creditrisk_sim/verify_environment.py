"""
Environment Verification Script
================================

Tests that all dependencies are installed and the project structure is correct.
"""

import sys
from pathlib import Path

def verify_imports():
    """Verify all required libraries can be imported."""
    print("=" * 70)
    print("  1. VERIFYING LIBRARY IMPORTS")
    print("=" * 70)
    
    libraries = [
        ('pandas', 'pandas'),
        ('numpy', 'numpy'),
        ('sklearn', 'scikit-learn'),
        ('shap', 'shap'),
        ('dice_ml', 'dice-ml'),
        ('matplotlib', 'matplotlib'),
        ('tqdm', 'tqdm'),
        ('fastapi', 'fastapi'),
        ('streamlit', 'streamlit'),
        ('pydantic', 'pydantic'),
        ('sqlalchemy', 'sqlalchemy'),
        ('sqlite_utils', 'sqlite-utils'),
        ('openml', 'openml'),
    ]
    
    all_ok = True
    for module_name, display_name in libraries:
        try:
            __import__(module_name)
            print(f"✅ {display_name}")
        except ImportError as e:
            print(f"❌ {display_name}: {e}")
            all_ok = False
    
    return all_ok


def verify_project_structure():
    """Verify all required files and directories exist."""
    print("\n" + "=" * 70)
    print("  2. VERIFYING PROJECT STRUCTURE")
    print("=" * 70)
    
    project_root = Path(__file__).parent
    
    required_items = [
        ('requirements.txt', 'file'),
        ('Makefile', 'file'),
        ('README.md', 'file'),
        ('__init__.py', 'file'),
        ('data', 'dir'),
        ('models', 'dir'),
        ('models/__init__.py', 'file'),
        ('models/train_model.py', 'file'),
        ('models/predict.py', 'file'),
        ('agents', 'dir'),
        ('agents/__init__.py', 'file'),
        ('agents/orchestrator.py', 'file'),
        ('agents/compliance.py', 'file'),
        ('agents/explainability.py', 'file'),
        ('agents/provenance.py', 'file'),
        ('agents/finops.py', 'file'),
        ('policies', 'dir'),
        ('policies/policy_registry.yaml', 'file'),
        ('simulation', 'dir'),
        ('simulation/__init__.py', 'file'),
        ('simulation/run_simulation.py', 'file'),
        ('ui', 'dir'),
        ('ui/__init__.py', 'file'),
        ('ui/console.py', 'file'),
    ]
    
    all_ok = True
    for item, item_type in required_items:
        item_path = project_root / item
        if item_type == 'file':
            exists = item_path.is_file()
        else:
            exists = item_path.is_dir()
        
        if exists:
            print(f"✅ {item}")
        else:
            print(f"❌ {item} (missing)")
            all_ok = False
    
    return all_ok


def verify_policy_registry():
    """Verify policy registry contains P1, P2, P3."""
    print("\n" + "=" * 70)
    print("  3. VERIFYING POLICY REGISTRY")
    print("=" * 70)
    
    try:
        import yaml
        policy_path = Path(__file__).parent / 'policies' / 'policy_registry.yaml'
        
        with open(policy_path) as f:
            registry = yaml.safe_load(f)
        
        policies = registry.get('policies', {})
        
        required_policies = ['P1', 'P2', 'P3']
        all_ok = True
        
        for policy_id in required_policies:
            if policy_id in policies:
                policy = policies[policy_id]
                print(f"✅ {policy_id}: {policy['desc']}")
                
                # Check specific attributes
                if policy_id == 'P1':
                    if 'psi_threshold' in policy and policy['psi_threshold'] == 0.2:
                        print(f"   ✓ PSI threshold: {policy['psi_threshold']}")
                    else:
                        print(f"   ✗ PSI threshold missing or incorrect")
                        all_ok = False
                
                elif policy_id == 'P2':
                    if 'shap_threshold' in policy and policy['shap_threshold'] == 0.05:
                        print(f"   ✓ SHAP threshold: {policy['shap_threshold']}")
                    else:
                        print(f"   ✗ SHAP threshold missing or incorrect")
                        all_ok = False
                    
                    if 'protected' in policy and set(policy['protected']) == {'age', 'job'}:
                        print(f"   ✓ Protected attributes: {policy['protected']}")
                    else:
                        print(f"   ✗ Protected attributes missing or incorrect")
                        all_ok = False
                
                elif policy_id == 'P3':
                    if 'counterfactual_required' in policy:
                        print(f"   ✓ Counterfactual required: {policy['counterfactual_required']}")
                    else:
                        print(f"   ✗ Counterfactual requirement missing")
                        all_ok = False
            else:
                print(f"❌ {policy_id} (missing)")
                all_ok = False
        
        return all_ok
    
    except Exception as e:
        print(f"❌ Error loading policy registry: {e}")
        return False


def verify_trained_model():
    """Check if model has been trained."""
    print("\n" + "=" * 70)
    print("  4. VERIFYING TRAINED MODEL")
    print("=" * 70)
    
    model_path = Path(__file__).parent / 'models' / 'model.pkl'
    encoder_path = Path(__file__).parent / 'models' / 'encoder.pkl'
    data_path = Path(__file__).parent / 'data' / 'german_credit.csv'
    
    all_ok = True
    
    if model_path.exists():
        print(f"✅ model.pkl exists ({model_path.stat().st_size / 1024:.1f} KB)")
    else:
        print(f"⚠️  model.pkl not found (run 'make train' first)")
        all_ok = False
    
    if encoder_path.exists():
        print(f"✅ encoder.pkl exists ({encoder_path.stat().st_size / 1024:.1f} KB)")
    else:
        print(f"⚠️  encoder.pkl not found (run 'make train' first)")
        all_ok = False
    
    if data_path.exists():
        print(f"✅ german_credit.csv exists ({data_path.stat().st_size / 1024:.1f} KB)")
    else:
        print(f"⚠️  german_credit.csv not found (run 'make train' first)")
        all_ok = False
    
    return all_ok


def main():
    """Run all verification checks."""
    print("\n")
    print("╔" + "=" * 68 + "╗")
    print("║" + " " * 15 + "AGENTIC CREDIT RISK SIMULATION" + " " * 23 + "║")
    print("║" + " " * 20 + "ENVIRONMENT VERIFICATION" + " " * 24 + "║")
    print("╚" + "=" * 68 + "╝")
    print()
    
    results = []
    
    # Run checks
    results.append(("Library Imports", verify_imports()))
    results.append(("Project Structure", verify_project_structure()))
    results.append(("Policy Registry", verify_policy_registry()))
    results.append(("Trained Model", verify_trained_model()))
    
    # Summary
    print("\n" + "=" * 70)
    print("  VERIFICATION SUMMARY")
    print("=" * 70)
    
    all_passed = all(result[1] for result in results)
    
    for check_name, passed in results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status:10s} {check_name}")
    
    print("\n" + "=" * 70)
    
    if all_passed:
        print("✅ ALL CHECKS PASSED")
        print("\nYour environment is ready!")
        print("\nNext steps:")
        print("  • Run simulation: make simulate")
        print("  • Launch UI: make ui")
        print("  • Or: python3 -m agentic_creditrisk_sim.models.train_model")
    else:
        print("⚠️  SOME CHECKS FAILED")
        print("\nPlease address the issues above.")
        print("Run 'make setup' to install dependencies.")
        print("Run 'make train' to train the model.")
    
    print("=" * 70)
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
